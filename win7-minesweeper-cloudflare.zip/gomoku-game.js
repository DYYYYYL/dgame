/* Two-player freestyle Gomoku: black starts; five or more stones wins. */
(function (global) {
  "use strict";

  class Gomoku {
    constructor({ state } = {}) {
      this.size = 15;
      this.reset();
      if (state !== undefined && !this._restore(state)) this.reset();
    }

    get canUndo() { return this.moves.length > 0; }

    reset() {
      this.board = Array(this.size * this.size).fill(0);
      this.moves = [];
      this.currentPlayer = 1;
      this.status = "playing";
      this.winner = 0;
      this.winningLine = [];
      return this;
    }

    place(index) {
      const player = this.currentPlayer;
      const result = { changed: false, index, player, won: this.status === "won", draw: this.status === "draw" };
      if (this.status !== "playing" || !Number.isInteger(index) || index < 0 || index >= this.board.length || this.board[index]) return result;
      this.board[index] = player;
      this.moves.push({ index, player });
      this.winningLine = this._findWin(index, player);
      if (this.winningLine.length) {
        this.status = "won";
        this.winner = player;
      } else if (this.moves.length === this.board.length) this.status = "draw";
      else this.currentPlayer = 3 - player;
      result.changed = true;
      result.won = this.status === "won";
      result.draw = this.status === "draw";
      return result;
    }

    undo() {
      const last = this.moves.pop();
      if (!last) return false;
      this.board[last.index] = 0;
      this.currentPlayer = last.player;
      this.status = "playing";
      this.winner = 0;
      this.winningLine = [];
      return true;
    }

    snapshot() {
      return { size: this.size, board: this.board.slice(), moves: this.moves.map(move => ({ ...move })),
        currentPlayer: this.currentPlayer, status: this.status, winner: this.winner, winningLine: this.winningLine.slice() };
    }

    _findWin(index, player) {
      const row = Math.floor(index / this.size), col = index % this.size;
      for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
        const line = [];
        for (let r = row - dr, c = col - dc; r >= 0 && r < this.size && c >= 0 && c < this.size && this.board[r * this.size + c] === player; r -= dr, c -= dc) {
          line.push(r * this.size + c);
        }
        line.reverse();
        line.push(index);
        for (let r = row + dr, c = col + dc; r >= 0 && r < this.size && c >= 0 && c < this.size && this.board[r * this.size + c] === player; r += dr, c += dc) {
          line.push(r * this.size + c);
        }
        if (line.length >= 5) return line;
      }
      return [];
    }

    _restore(state) {
      try {
        if (!state || typeof state !== "object" || Array.isArray(state) ||
            "size" in state && state.size !== this.size || !Array.isArray(state.moves) || state.moves.length > this.board.length) return false;
        // Derived board, turn and terminal flags are rebuilt; saved flags cannot bypass a win.
        for (const move of state.moves) {
          if (!move || typeof move !== "object" || move.player !== this.currentPlayer || !this.place(move.index).changed) return false;
        }
        return true;
      } catch { return false; }
    }
  }

  global.Gomoku = Gomoku;
  if (typeof module !== "undefined" && module.exports) module.exports = { Gomoku };
})(typeof globalThis !== "undefined" ? globalThis : window);
