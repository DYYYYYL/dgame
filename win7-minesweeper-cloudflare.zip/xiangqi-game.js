/* Local two-player Xiangqi. Tournament repetition/chasing rulings are not automated. */
(function (global) {
  "use strict";
  const ROWS = 10, COLS = 9, other = side => side === "r" ? "b" : "r";
  const inside = (row, col) => row >= 0 && row < ROWS && col >= 0 && col < COLS;
  const palace = (side, row, col) => col >= 3 && col <= 5 && (side === "r" ? row >= 7 && row <= 9 : row >= 0 && row <= 2);

  class Xiangqi {
    constructor({ state } = {}) {
      this.reset();
      if (state !== undefined && !this._restore(state)) this.reset();
    }

    get canUndo() { return this._actions.length > 0; }

    reset() {
      this.board = Array(ROWS * COLS).fill(null);
      const back = ["R", "N", "B", "A", "K", "A", "B", "N", "R"];
      for (let col = 0; col < COLS; col++) {
        this.board[col] = "b" + back[col];
        this.board[81 + col] = "r" + back[col];
      }
      for (const col of [1, 7]) { this.board[18 + col] = "bC"; this.board[63 + col] = "rC"; }
      for (const col of [0, 2, 4, 6, 8]) { this.board[27 + col] = "bP"; this.board[54 + col] = "rP"; }
      this.currentPlayer = "r";
      this.status = "playing";
      this.winner = null;
      this.inCheck = false;
      this.reason = "";
      this.moves = [];
      this._actions = [];
      return this;
    }

    legalMoves(from) {
      if (this.status !== "playing" || !this._valid(from) || this.board[from]?.[0] !== this.currentPlayer) return [];
      return this._safeMoves(from, this.currentPlayer);
    }

    move(from, to) {
      const piece = this._valid(from) ? this.board[from] : null, player = this.currentPlayer;
      const result = { changed: false, from, to, player, piece, captured: null, check: false, won: this.status === "won" };
      if (!this._valid(to) || !this.legalMoves(from).includes(to)) return result;
      const captured = this.board[to];
      this.board[to] = piece; this.board[from] = null;
      this.currentPlayer = other(player);
      if (captured === this.currentPlayer + "K") {
        this.status = "won"; this.winner = player; this.reason = "king-captured"; this.inCheck = false;
      } else {
        this.inCheck = this._isInCheck(this.currentPlayer);
        if (!this._hasLegalMoves(this.currentPlayer)) {
          this.status = "won"; this.winner = player;
          this.reason = this.inCheck ? "checkmate" : "stalemate";
        }
      }
      const record = { from, to, player, piece, captured, check: this.inCheck };
      this.moves.push(record); this._actions.push({ type: "move", ...record });
      return { ...result, changed: true, captured, check: this.inCheck, won: this.status === "won" };
    }

    resign(player = this.currentPlayer) {
      if (this.status !== "playing" || !["r", "b"].includes(player)) return false;
      this._actions.push({ type: "resign", player });
      this.status = "won"; this.winner = other(player); this.reason = "resigned";
      return true;
    }

    agreeDraw() {
      if (this.status !== "playing") return false;
      this._actions.push({ type: "draw" });
      this.status = "draw"; this.winner = null; this.reason = "agreed-draw";
      return true;
    }

    undo() {
      const action = this._actions.pop();
      if (!action) return false;
      if (action.type === "move") {
        this.board[action.from] = action.piece; this.board[action.to] = action.captured;
        this.currentPlayer = action.player; this.moves.pop();
      }
      this.status = "playing"; this.winner = null; this.reason = "";
      this.inCheck = this._isInCheck(this.currentPlayer);
      return true;
    }

    snapshot() {
      return { board: this.board.slice(), currentPlayer: this.currentPlayer, status: this.status,
        winner: this.winner, inCheck: this.inCheck, reason: this.reason,
        moves: this.moves.map(move => ({ ...move })), actions: this._actions.map(action => ({ ...action })) };
    }

    _valid(index) { return Number.isInteger(index) && index >= 0 && index < ROWS * COLS; }

    _pseudoMoves(from, board = this.board) {
      const piece = board[from];
      if (!piece) return [];
      const side = piece[0], type = piece[1], row = Math.floor(from / COLS), col = from % COLS, result = [];
      const add = (r, c) => { if (inside(r, c) && board[r * COLS + c]?.[0] !== side) result.push(r * COLS + c); };
      if (type === "R" || type === "C") {
        for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
          let screen = false;
          for (let r = row + dr, c = col + dc; inside(r, c); r += dr, c += dc) {
            const index = r * COLS + c, target = board[index];
            if (type === "R") { if (!target) result.push(index); else { if (target[0] !== side) result.push(index); break; } }
            else if (!screen) { if (!target) result.push(index); else screen = true; }
            else if (target) { if (target[0] !== side) result.push(index); break; }
          }
        }
      } else if (type === "N") {
        for (const [dr, dc] of [[-2,-1],[-2,1],[2,-1],[2,1],[-1,-2],[1,-2],[-1,2],[1,2]]) {
          const r = row + dr, c = col + dc;
          const legRow = row + (Math.abs(dr) === 2 ? dr / 2 : 0), legCol = col + (Math.abs(dc) === 2 ? dc / 2 : 0);
          if (inside(r, c) && !board[legRow * COLS + legCol]) add(r, c);
        }
      } else if (type === "B") {
        for (const [dr, dc] of [[-2,-2],[-2,2],[2,-2],[2,2]]) {
          const r = row + dr, c = col + dc;
          if (inside(r, c) && (side === "r" ? r >= 5 : r <= 4) && !board[(row + dr / 2) * COLS + col + dc / 2]) add(r, c);
        }
      } else if (type === "A") {
        for (const [dr, dc] of [[-1,-1],[-1,1],[1,-1],[1,1]]) if (palace(side, row + dr, col + dc)) add(row + dr, col + dc);
      } else if (type === "K") {
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]]) if (palace(side, row + dr, col + dc)) add(row + dr, col + dc);
        // The flying general is also the attack used to reject facing kings.
        for (const dr of [-1, 1]) for (let r = row + dr; inside(r, col); r += dr) {
          const index = r * COLS + col;
          if (board[index]) { if (board[index] === other(side) + "K") result.push(index); break; }
        }
      } else if (type === "P") {
        add(row + (side === "r" ? -1 : 1), col);
        if (side === "r" ? row <= 4 : row >= 5) { add(row, col - 1); add(row, col + 1); }
      }
      return [...new Set(result)];
    }

    _isInCheck(side, board = this.board) {
      const king = board.indexOf(side + "K");
      if (king < 0) return true;
      for (let from = 0; from < board.length; from++) if (board[from]?.[0] === other(side) && this._pseudoMoves(from, board).includes(king)) return true;
      return false;
    }

    _safeMoves(from, side) {
      return this._pseudoMoves(from).filter(to => {
        const board = this.board.slice(); board[to] = board[from]; board[from] = null;
        return !this._isInCheck(side, board);
      });
    }

    _hasLegalMoves(side) {
      for (let from = 0; from < this.board.length; from++) if (this.board[from]?.[0] === side && this._safeMoves(from, side).length) return true;
      return false;
    }

    _restore(state) {
      try {
        if (!state || typeof state !== "object" || Array.isArray(state)) return false;
        const actions = state.actions === undefined && Array.isArray(state.moves)
          ? state.moves.map(move => ({ ...move, type: "move" })) : state.actions;
        if (!Array.isArray(actions)) return false;
        for (const action of actions) {
          if (!action || typeof action !== "object" || this.status !== "playing") return false;
          if (action.type === "move") {
            if ("player" in action && action.player !== this.currentPlayer ||
                "piece" in action && action.piece !== this.board[action.from] ||
                "captured" in action && action.captured !== this.board[action.to]) return false;
            const result = this.move(action.from, action.to);
            if (!result.changed || "check" in action && action.check !== result.check) return false;
          } else if (action.type === "resign") { if (!this.resign(action.player)) return false; }
          else if (action.type === "draw") { if (!this.agreeDraw()) return false; }
          else return false;
        }
        return true;
      } catch { return false; }
    }
  }

  global.Xiangqi = Xiangqi;
  if (typeof module !== "undefined" && module.exports) module.exports = { Xiangqi };
})(typeof globalThis !== "undefined" ? globalThis : window);
