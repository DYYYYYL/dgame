/* 2048: saved input → game model → animated view → CSV export. */
(() => {
  "use strict";
  const $ = id => document.getElementById(id), win = $("game2048-window");
  if (!win || typeof Game2048 !== "function") return;
  const KEY = "win7-2048-v1", board = $("g2048-board"), tiles = $("g2048-tiles"), overlay = $("g2048-overlay");
  const read = () => { try { const data = JSON.parse(localStorage.getItem(KEY)); return data && typeof data === "object" ? data : {}; } catch { return {}; } };
  const saved = read();
  let game;
  try { game = new Game2048({ state: saved.state }); } catch { game = new Game2048(); }
  let best = Math.max(Number.isFinite(saved.best) && saved.best >= 0 ? saved.best : 0, game.score);
  let started = Number.isFinite(Date.parse(saved.started)) ? saved.started : new Date().toISOString();
  let active = false, overlayKind = null, returnFocus = null, storageOK = true, generation = 0, animations = [], swipe = null, terminalTimer = null;
  $("g2048-cells").innerHTML = Array.from({ length: 16 }, (_, index) => `<div class="g2048-slot" role="gridcell" data-index="${index}" aria-rowindex="${Math.floor(index / 4) + 1}" aria-colindex="${index % 4 + 1}"></div>`).join("");
  const canUndo = () => !!game.canUndo;
  const status = () => game.over ? "over" : game.won ? "won" : "playing";
  const save = () => {
    best = Math.max(best, game.score);
    try { localStorage.setItem(KEY, JSON.stringify({ state: game.snapshot(), best, started })); storageOK = true; }
    catch { storageOK = false; }
  };
  function makeTile(value, index, extra = "") {
    const tile = document.createElement("div"), col = index % 4, row = Math.floor(index / 4);
    tile.className = `g2048-tile${value > 2048 ? " g2048-high" : ""}${extra ? ` ${extra}` : ""}`;
    tile.dataset.value = value; tile.dataset.index = index; tile.textContent = value;
    tile.style.left = `calc(${col * 25}% + ${col / 4} * var(--g2048-gap))`;
    tile.style.top = `calc(${row * 25}% + ${row / 4} * var(--g2048-gap))`;
    return tile;
  }
  function renderBoard(pending = new Set()) {
    const fragment = document.createDocumentFragment();
    game.board.forEach((value, index) => {
      if (value) fragment.append(makeTile(value, index, pending.has(index) ? "g2048-pending" : ""));
      const slot = $("g2048-cells").children[index];
      slot.dataset.value = value;
      slot.setAttribute("aria-label", `第 ${Math.floor(index / 4) + 1} 行，第 ${index % 4 + 1} 列，${value || "空白"}`);
    });
    tiles.replaceChildren(fragment);
    board.dataset.status = status(); board.dataset.moves = game.moves; board.dataset.score = game.score;
  }
  function renderMeta() {
    $("g2048-score").textContent = game.score;
    $("g2048-best").textContent = best;
    $("g2048-moves").textContent = game.moves;
    $("g2048-undo").disabled = !canUndo();
    $("g2048-status").textContent = !storageOK ? "本地存储不可用，本局仍可正常游玩" : game.over ? "没有可移动的方向了，可撤销上一步" : game.won ? "已经合成 2048，继续挑战更大的数字！" : "合并相同数字，向 2048 前进";
  }
  function cancelTerminal() { clearTimeout(terminalTimer); terminalTimer = null; }
  function finishMotion() {
    cancelTerminal();
    generation++;
    animations.forEach(animation => animation.cancel()); animations = [];
    $("g2048-score-gain").textContent = "";
    renderBoard();
  }
  function animate(element, keyframes, options) {
    if (!element?.animate) return null;
    const animation = element.animate(keyframes, options); animation.finished.catch(() => {}); animations.push(animation); return animation;
  }
  function animateMove(change) {
    const token = generation, moving = change.movements.filter(m => m.from !== m.to || m.merged);
    const pending = new Set(moving.map(m => m.to));
    if (change.spawned) pending.add(change.spawned.index);
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduced || !tiles.animate || !tiles.clientWidth) { renderBoard(); return; }
    renderBoard(pending);
    const gap = parseFloat(getComputedStyle(win).getPropertyValue("--g2048-gap")) || 9;
    const step = (tiles.clientWidth + gap) / 4;
    const motion = moving.map(m => {
      const ghost = makeTile(m.value, m.from, "g2048-ghost"); tiles.append(ghost);
      const dx = (m.to % 4 - m.from % 4) * step, dy = (Math.floor(m.to / 4) - Math.floor(m.from / 4)) * step;
      return animate(ghost, [{ transform: "translate(0,0)" }, { transform: `translate(${dx}px,${dy}px)` }], { duration: 110, easing: "cubic-bezier(.2,.65,.3,1)", fill: "forwards" });
    }).filter(Boolean);
    if (change.scoreDelta) {
      const gain = $("g2048-score-gain"); gain.textContent = `+${change.scoreDelta}`;
      animate(gain, [{ opacity: 1, transform: "translateY(0)" }, { opacity: 0, transform: "translateY(-25px)" }], { duration: 450, easing: "ease-out", fill: "forwards" });
    }
    Promise.all(motion.map(animation => animation.finished.catch(() => {}))).then(() => {
      if (generation !== token) return;
      renderBoard();
      change.merged.forEach(index => animate(tiles.querySelector(`[data-index="${index}"]`), [{ transform: "scale(.9)" }, { transform: "scale(1.1)", offset: .45 }, { transform: "scale(1)" }], { duration: 130, easing: "ease-out" }));
      if (change.spawned) animate(tiles.querySelector(`[data-index="${change.spawned.index}"]`), [{ opacity: 0, transform: "scale(.4)" }, { opacity: 1, transform: "scale(1)" }], { duration: 110, easing: "ease-out" });
    });
  }
  function focusBoard() { if (active && !win.hidden) board.focus({ preventScroll: true }); }
  function showOverlay(kind) {
    cancelTerminal();
    if (!overlayKind) returnFocus = document.activeElement;
    overlayKind = kind;
    const messages = {
      confirm: ["↻", "开始新游戏？", "当前局面会被新的棋盘替换。\n最高分会一直保留。", "开始新游戏", "继续当前局"],
      help: ["2048", "如何玩 2048", "方向键或 WASD 移动所有方块。\n相同数字相撞会合并，目标是 2048。\n手机上滑动棋盘，也可点下方方向按钮。\n每步都能单次撤销，F2 开始新游戏。", "知道了", ""],
      won: ["2048", "你做到了！", "恭喜合成 2048。\n继续挑战，看看还能走多远。", "继续挑战", "新游戏"],
      over: ["↺", "暂时走到这里", "棋盘已满，没有可以合并的数字。\n撤销一步，试试另一个方向。", canUndo() ? "撤销上一步" : "新游戏", canUndo() ? "新游戏" : ""]
    };
    const [symbol, title, text, primary, secondary] = messages[kind];
    $("g2048-overlay-symbol").textContent = symbol;
    $("g2048-overlay-title").textContent = title;
    $("g2048-overlay-text").textContent = text;
    $("g2048-overlay-primary").textContent = primary;
    $("g2048-overlay-secondary").textContent = secondary;
    $("g2048-overlay-secondary").hidden = !secondary;
    overlay.hidden = false;
    if (active) $("g2048-overlay-primary").focus({ preventScroll: true });
  }
  function hideOverlay() {
    overlayKind = null; overlay.hidden = true;
    if (active) {
      if (returnFocus && win.contains(returnFocus) && !returnFocus.disabled && !overlay.contains(returnFocus)) returnFocus.focus({ preventScroll: true });
      else focusBoard();
    }
    returnFocus = null;
  }
  function terminal(delay = 0) {
    cancelTerminal();
    const kind = game.over ? "over" : game.won && !game.keepPlaying ? "won" : null;
    if (!kind || !active || overlayKind) return;
    if (!delay) { showOverlay(kind); return; }
    const token = generation;
    terminalTimer = setTimeout(() => {
      terminalTimer = null;
      if (token === generation && active && !overlayKind) showOverlay(kind);
    }, delay);
  }
  function restart() {
    finishMotion(); game.restart(); started = new Date().toISOString(); swipe = null;
    hideOverlay(); save(); renderBoard(); renderMeta(); focusBoard();
  }
  function requestNew() { finishMotion(); if (game.moves > 0 && !game.over) showOverlay("confirm"); else restart(); }
  function undo() {
    finishMotion();
    if (!game.undo()) { terminal(); return false; }
    hideOverlay(); save(); renderBoard(); renderMeta(); terminal(); return true;
  }
  function playable() { return active && !win.hidden && !overlayKind && !game.over && !(game.won && !game.keepPlaying) && !document.querySelector("dialog[open]"); }
  function move(direction) {
    if (!playable()) return;
    // Finish the prior frame; every input reaches the model without a lock or queue.
    finishMotion();
    const change = game.move(direction);
    if (change.changed) { save(); renderMeta(); animateMove(change); }
    else { renderBoard(); renderMeta(); }
    terminal(change.changed ? 220 : 0);
  }
  function exportCSV() {
    const row = [new Date().toISOString(), game.score, best, game.moves, Math.max(...game.board), status()];
    const quote = value => `"${String(value).replaceAll('"', '""')}"`;
    const csv = "\uFEFF" + [["date", "score", "best", "moves", "maxTile", "status"], row].map(values => values.map(quote).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" })), link = document.createElement("a");
    link.href = url; link.download = `2048-${new Date().toISOString().slice(0, 10)}.csv`; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const actions = { new: requestNew, undo, help: () => showOverlay("help"), export: exportCSV };
  win.querySelectorAll("[data-2048-action]").forEach(button => button.addEventListener("click", () => actions[button.dataset["2048Action"]]()));
  win.querySelectorAll("[data-2048-direction]").forEach(button => button.addEventListener("click", () => move(button.dataset["2048Direction"])));
  $("g2048-overlay-primary").addEventListener("click", () => {
    if (overlayKind === "confirm") restart();
    else if (overlayKind === "help") { hideOverlay(); terminal(); }
    else if (overlayKind === "won") { game.continueGame(); hideOverlay(); save(); renderMeta(); focusBoard(); }
    else if (overlayKind === "over") canUndo() ? undo() : restart();
  });
  $("g2048-overlay-secondary").addEventListener("click", () => { if (overlayKind === "confirm") { hideOverlay(); terminal(); } else restart(); });
  const maximize = () => {
    finishMotion(); win.classList.toggle("maximized");
    const label = win.classList.contains("maximized") ? "还原 2048 窗口" : "最大化 2048";
    $("g2048-maximize").title = label; $("g2048-maximize").setAttribute("aria-label", label);
    terminal();
  };
  $("g2048-maximize").addEventListener("click", maximize);
  $("g2048-titlebar").addEventListener("dblclick", event => { if (!event.target.closest("button")) maximize(); });
  document.addEventListener("desktop:gamechange", event => {
    active = event.detail?.game === "2048"; swipe = null; finishMotion();
    if (active && !overlayKind) terminal();
    else if (active) $("g2048-overlay-primary").focus({ preventScroll: true });
  });
  document.addEventListener("keydown", event => {
    if (!active || win.hidden || event.ctrlKey || event.altKey || event.metaKey ||
        event.target.closest?.("input,select,textarea,[contenteditable='true']") || document.querySelector("dialog[open]")) return;
    if (overlayKind) { if (event.key === "Escape" && ["confirm", "help"].includes(overlayKind)) { event.preventDefault(); hideOverlay(); terminal(); } return; }
    const directions = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down", a: "left", d: "right", w: "up", s: "down" };
    const direction = directions[event.key] || directions[event.key.toLowerCase()];
    if (direction) { event.preventDefault(); move(direction); }
    else if (event.key === "F2") { event.preventDefault(); requestNew(); }
    else if (event.key === "F1") { event.preventDefault(); showOverlay("help"); }
  });
  const swipeDirection = event => {
    if (!swipe || swipe.id !== event.pointerId || swipe.fired) return;
    const dx = event.clientX - swipe.x, dy = event.clientY - swipe.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    swipe.fired = true;
    move(Math.abs(dx) >= Math.abs(dy) ? dx > 0 ? "right" : "left" : dy > 0 ? "down" : "up");
  };
  board.addEventListener("pointerdown", event => {
    if (!playable() || event.button > 0 || event.isPrimary === false) { swipe = null; return; }
    swipe = { id: event.pointerId, x: event.clientX, y: event.clientY, fired: false };
    try { board.setPointerCapture(event.pointerId); } catch { /* Synthetic events have no capture target. */ }
  });
  board.addEventListener("pointermove", swipeDirection);
  board.addEventListener("pointerup", event => { swipeDirection(event); if (swipe?.id === event.pointerId) swipe = null; });
  board.addEventListener("pointercancel", () => { swipe = null; });
  board.addEventListener("lostpointercapture", () => { swipe = null; });
  board.addEventListener("contextmenu", event => event.preventDefault());
  document.addEventListener("pointerdown", event => { if (swipe && event.pointerId !== swipe.id) swipe = null; }, true);
  window.addEventListener("blur", () => { swipe = null; finishMotion(); });
  window.addEventListener("focus", () => terminal());
  window.addEventListener("resize", () => { finishMotion(); terminal(); });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) { swipe = null; finishMotion(); }
    else terminal();
  });
  window.Win2048UI = { newGame: requestNew, undo, exportCSV, snapshot: () => ({ state: game.snapshot(), best }), open: () => document.dispatchEvent(new CustomEvent("desktop:open", { detail: { game: "2048" } })) };
  save(); renderBoard(); renderMeta(); terminal();
})();
