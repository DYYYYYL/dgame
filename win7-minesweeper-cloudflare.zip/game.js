(function (global) {
  "use strict";

  class MinesweeperGame {
    constructor({ rows, cols, mines, random = Math.random }) {
      if (![rows, cols, mines].every(Number.isSafeInteger) || rows < 1 || cols < 1 ||
          !Number.isSafeInteger(rows * cols) || mines < 0 || mines >= rows * cols) {
        throw new RangeError("Rows and columns must be positive integers; mines must be less than the board size.");
      }
      if (typeof random !== "function") throw new TypeError("random must be a function.");
      this.rows = rows;
      this.cols = cols;
      this.mines = mines;
      this.random = random;
      this.cells = Array.from({ length: rows * cols }, () => ({
        mine: false, adjacent: 0, revealed: false, mark: 0
      }));
      this.status = "ready";
      this.flags = 0;
      this.revealed = 0;
      this.exploded = -1;
    }

    neighbors(index) {
      if (!this._valid(index)) return [];
      const row = Math.floor(index / this.cols), col = index % this.cols, result = [];
      for (let r = Math.max(0, row - 1); r <= Math.min(this.rows - 1, row + 1); r++) {
        for (let c = Math.max(0, col - 1); c <= Math.min(this.cols - 1, col + 1); c++) {
          const next = r * this.cols + c;
          if (next !== index) result.push(next);
        }
      }
      return result;
    }

    reveal(index) {
      const result = this._result();
      if (!this._active() || !this._valid(index)) return result;
      const cell = this.cells[index];
      if (cell.revealed || cell.mark === 1) return result;
      if (this.status === "ready") {
        this._placeMines(index);
        this.status = "playing";
        result.started = true;
      }
      this._open([index], result);
      return result;
    }

    cycleMark(index, questionMarks = true) {
      const result = this._result();
      if (!this._active() || !this._valid(index) || this.cells[index].revealed) return result;
      const cell = this.cells[index], previous = cell.mark;
      cell.mark = previous === 0 ? 1 : previous === 1 && questionMarks ? 2 : 0;
      this.flags += Number(cell.mark === 1) - Number(previous === 1);
      result.changed.push(index);
      return result;
    }

    chord(index) {
      const result = this._result();
      if (this.status !== "playing" || !this._valid(index)) return result;
      const cell = this.cells[index];
      if (!cell.revealed || cell.mine || cell.adjacent === 0) return result;
      const neighbors = this.neighbors(index);
      if (neighbors.filter(next => this.cells[next].mark === 1).length !== cell.adjacent) return result;
      this._open(neighbors, result);
      return result;
    }

    _valid(index) {
      return Number.isInteger(index) && index >= 0 && index < this.cells.length;
    }

    _active() {
      return this.status === "ready" || this.status === "playing";
    }

    _result() {
      return { changed: [], started: false, ended: false };
    }

    _placeMines(first) {
      // On dense custom boards, protect as much of the first 3 × 3 as possible.
      const protectedCells = new Set([first, ...this.neighbors(first)].slice(0, this.cells.length - this.mines));
      const candidates = [];
      for (let i = 0; i < this.cells.length; i++) if (!protectedCells.has(i)) candidates.push(i);
      // Partial Fisher–Yates: select only the required number of mine positions.
      for (let i = 0; i < this.mines; i++) {
        const sample = Number(this.random());
        const fraction = Number.isFinite(sample) ? Math.max(0, Math.min(1 - Number.EPSILON, sample)) : 0;
        const selected = i + Math.floor(fraction * (candidates.length - i));
        [candidates[i], candidates[selected]] = [candidates[selected], candidates[i]];
        const index = candidates[i];
        this.cells[index].mine = true;
        for (const neighbor of this.neighbors(index)) this.cells[neighbor].adjacent++;
      }
    }

    _open(seeds, result) {
      const queued = new Uint8Array(this.cells.length), queue = [];
      const enqueue = index => {
        const cell = this.cells[index];
        if (!queued[index] && !cell.revealed && cell.mark !== 1) {
          queued[index] = 1;
          queue.push(index);
        }
      };
      seeds.forEach(enqueue);
      for (let cursor = 0; cursor < queue.length; cursor++) {
        const index = queue[cursor], cell = this.cells[index];
        cell.revealed = true;
        cell.mark = 0;
        result.changed.push(index);
        if (cell.mine) {
          this.exploded = index;
          this.status = "lost";
          result.ended = true;
          return;
        }
        this.revealed++;
        if (cell.adjacent === 0) this.neighbors(index).forEach(enqueue);
      }
      if (this.revealed === this.cells.length - this.mines) {
        this.status = "won";
        result.ended = true;
        this.cells.forEach((cell, index) => {
          if (cell.mine && cell.mark !== 1) {
            cell.mark = 1;
            result.changed.push(index);
          }
        });
        this.flags = this.mines;
      }
    }
  }

  global.MinesweeperGame = MinesweeperGame;
  if (typeof module !== "undefined" && module.exports) module.exports = { MinesweeperGame };
})(typeof globalThis !== "undefined" ? globalThis : window);
