/* Immediate, gesture-scoped input; the game model remains the source of truth. */
(function (global) {
  "use strict";

  function bindMinesweeperInput(board, { cell, neighbors, enabled, activate, preview, focus }) {
    const doc = board.ownerDocument, view = doc.defaultView || global, listeners = [], pointers = new Set();
    let mouse = null, touch = null, compatibilityMouse = false;
    const listen = (target, type, callback, options) => {
      target.addEventListener(type, callback, options);
      listeners.push(() => target.removeEventListener(type, callback, options));
    };
    const indexAt = target => {
      const element = target?.closest?.(".cell");
      if (!element || !board.contains(element)) return null;
      const index = Number(element.dataset.index);
      return Number.isInteger(index) && cell(index) ? index : null;
    };
    const hitIndex = event => indexAt(typeof doc.elementFromPoint === "function" &&
      Number.isFinite(event.clientX) && Number.isFinite(event.clientY)
      ? doc.elementFromPoint(event.clientX, event.clientY) : event.target);
    const chordable = index => cell(index)?.revealed && cell(index).adjacent > 0;
    const show = (index, chord = false) => {
      if (index === null || !enabled()) return preview([]);
      const indices = chord ? (chordable(index) ? neighbors(index) : []) : [index];
      preview(indices.filter(next => { const c = cell(next); return c && !c.revealed && c.mark !== 1; }));
    };
    const invoke = (type, index) => {
      if (index === null || !enabled()) return;
      focus(index);
      activate(type, index);
    };
    const open = index => invoke(cell(index)?.revealed ? "chord" : "reveal", index);
    const cancelTouch = () => {
      if (touch) clearTimeout(touch.timer);
      touch = null;
      preview([]);
    };
    const reset = () => {
      mouse = null;
      cancelTouch();
      pointers.clear();
    };
    const fromTouch = event => compatibilityMouse || event.sourceCapabilities?.firesTouchEvents;

    // Mouse Events report every button transition, unlike pointerdown/pointerup.
    listen(board, "mousedown", event => {
      if (fromTouch(event) || !enabled() || ![0, 1, 2].includes(event.button)) return;
      const index = indexAt(event.target);
      if (index === null) return;
      const bit = [1, 4, 2][event.button], buttons = event.buttons ?? bit;
      if (!mouse || !(buttons & ~bit)) mouse = { mode: "", done: false };
      mouse.index = index;
      mouse.buttons = buttons;
      if (mouse.done) return;
      if (event.button === 1 || (buttons & 3) === 3 || mouse.mode === "chord") {
        event.preventDefault();
        mouse.mode = "chord";
        show(index, true);
      } else if (event.button === 2) {
        mouse.mode = "right";
        preview([]);
        if (!cell(index)?.revealed) invoke("flag", index);
      } else {
        mouse.mode = "left";
        show(index, !!cell(index)?.revealed);
      }
    });
    listen(doc, "mousemove", event => {
      if (!mouse || mouse.done || fromTouch(event)) return;
      if (event.buttons === 0) { mouse = null; preview([]); return; }
      mouse.index = indexAt(event.target);
      if (mouse.mode !== "right") show(mouse.index, mouse.mode === "chord" || !!cell(mouse.index)?.revealed);
    });
    listen(doc, "mouseup", event => {
      if (!mouse || fromTouch(event)) return;
      const gesture = mouse, index = indexAt(event.target);
      const act = !gesture.done && index !== null;
      gesture.done = true;
      mouse = event.buttons ? gesture : null;
      preview([]);
      if (!act) return;
      if (gesture.mode === "chord") { if (chordable(index)) invoke("chord", index); }
      else if (gesture.mode === "left" && event.button === 0) open(index);
    });

    // Pointer Events distinguish real mouse input from touch compatibility events.
    // No preventDefault/capture here: native panning and pointercancel stay intact.
    listen(doc, "pointerdown", event => {
      if (event.pointerType === "mouse") { compatibilityMouse = false; return; }
      compatibilityMouse = true;
      pointers.add(event.pointerId);
      if (pointers.size > 1 || event.isPrimary === false) { cancelTouch(); return; }
      const index = indexAt(event.target);
      if (index === null || !enabled()) return;
      cancelTouch();
      const gesture = touch = { id: event.pointerId, index, x: event.clientX, y: event.clientY, moved: false, marked: false, timer: null };
      show(index, !!cell(index)?.revealed);
      if (!cell(index)?.revealed) gesture.timer = setTimeout(() => {
        if (touch !== gesture || gesture.moved || pointers.size !== 1 || !enabled()) return;
        gesture.marked = true;
        preview([]);
        invoke("flag", index);
      }, 350);
    }, true);
    const moveTouch = event => {
      if (!touch || touch.id !== event.pointerId || touch.moved) return;
      if (Math.hypot(event.clientX - touch.x, event.clientY - touch.y) > 10) {
        touch.moved = true;
        clearTimeout(touch.timer);
        preview([]);
      }
    };
    listen(doc, "pointermove", moveTouch, true);
    listen(doc, "pointerup", event => {
      if (event.pointerType === "mouse") return;
      moveTouch(event);
      const gesture = touch;
      pointers.delete(event.pointerId);
      if (!gesture || gesture.id !== event.pointerId) return;
      const tap = !gesture.moved && !gesture.marked && hitIndex(event) === gesture.index;
      cancelTouch();
      if (tap) open(gesture.index);
    }, true);
    listen(doc, "pointercancel", event => {
      if (event.pointerType === "mouse") { mouse = null; preview([]); return; }
      pointers.delete(event.pointerId);
      if (touch?.id === event.pointerId) cancelTouch();
    }, true);
    listen(board, "contextmenu", event => event.preventDefault());
    listen(board, "auxclick", event => event.preventDefault());
    // Physical clicks already ran on mouseup/pointerup. Detail 0 supports AT.
    listen(board, "click", event => {
      if (event.detail !== 0 || event.sourceCapabilities?.firesTouchEvents ||
          event.pointerType && event.pointerType !== "mouse") return;
      const index = indexAt(event.target);
      if (index !== null) open(index);
    });
    listen(view, "blur", reset);
    listen(doc, "visibilitychange", () => { if (doc.hidden) reset(); });
    return { reset, destroy() { reset(); listeners.forEach(remove => remove()); } };
  }

  global.bindMinesweeperInput = bindMinesweeperInput;
  if (typeof module !== "undefined" && module.exports) module.exports = { bindMinesweeperInput };
})(typeof globalThis !== "undefined" ? globalThis : window);
