/* Sliding puzzle model: legal blank moves preserve solvability. */
(function (global) {
  "use strict";
  const validSize = size => Number.isInteger(size) && size >= 3 && size <= 10;
  const solved = board => board.every((value, index) => value === (index + 1) % board.length);
  const copy = state => ({ size: state.size, board: state.board.slice(), blank: state.blank, steps: state.steps, status: state.status });

  class SlidingPuzzle {
    constructor({ size = 4, random = Math.random, state } = {}) {
      this.random = typeof random === "function" ? random : Math.random;
      this._previous = null;
      const restored = SlidingPuzzle._readState(state);
      if (restored) {
        Object.assign(this, restored);
        try {
          const previous = SlidingPuzzle._readState(state.undo);
          if (previous?.size === restored.size) this._previous = previous;
        } catch { /* A damaged optional undo record does not discard a valid board. */ }
      } else this.shuffle(validSize(size) ? size : 4);
    }

    get canUndo() { return this._previous !== null; }

    neighborIndices(index = this.blank) {
      if (!Number.isInteger(index) || index < 0 || index >= this.board.length) return [];
      const row = Math.floor(index / this.size), col = index % this.size, result = [];
      if (row > 0) result.push(index - this.size);
      if (row < this.size - 1) result.push(index + this.size);
      if (col > 0) result.push(index - 1);
      if (col < this.size - 1) result.push(index + 1);
      return result;
    }

    canMove(index) {
      return this.status !== "won" && Number.isInteger(index) && index >= 0 && index < this.board.length &&
        this.board[index] !== 0 && Math.abs(Math.floor(index / this.size) - Math.floor(this.blank / this.size)) +
        Math.abs(index % this.size - this.blank % this.size) === 1;
    }

    move(index) {
      const result = { changed: false, from: Number.isInteger(index) ? index : -1, to: this.blank, value: 0, won: this.status === "won" };
      if (!this.canMove(index)) return result;
      this._previous = copy(this);
      result.value = this.board[index];
      this._swap(index);
      this.steps++;
      this.status = solved(this.board) ? "won" : "playing";
      result.changed = true;
      result.won = this.status === "won";
      return result;
    }

    moveBlank(direction) {
      const offsets = { left: -1, right: 1, up: -this.size, down: this.size };
      return this.move(Object.hasOwn(offsets, direction) ? this.blank + offsets[direction] : -1);
    }

    shuffle(size = this.size) {
      this.size = validSize(size) ? size : validSize(this.size) ? this.size : 4;
      this.board = Array.from({ length: this.size * this.size }, (_, index) => (index + 1) % (this.size * this.size));
      this.blank = this.board.length - 1;
      let previous = -1;
      for (let step = 0; step < this.board.length * 40; step++) {
        const candidates = this.neighborIndices().filter(index => index !== previous);
        const next = candidates[Math.floor(this._sample() * candidates.length)];
        previous = this.blank;
        this._swap(next);
      }
      // Constant/extreme random sources can cycle. Add legal outward moves if the result is too shallow.
      let distance = this._distance();
      const minimum = Math.max(6, Math.floor(this.board.length / 2));
      for (let step = 0; distance < minimum && step < this.board.length * 8; step++) {
        const candidates = this.neighborIndices().filter(index => index !== previous);
        const deltas = candidates.map(index => this._tileDistance(this.board[index], this.blank) - this._tileDistance(this.board[index], index));
        const best = Math.max(...deltas), choices = candidates.filter((_, index) => deltas[index] === best);
        const next = choices[Math.floor(this._sample() * choices.length)];
        previous = this.blank;
        this._swap(next);
        distance += best;
      }
      if (solved(this.board)) this._swap(this.neighborIndices().find(index => index !== previous));
      this.steps = 0;
      this.status = "ready";
      this._previous = null;
      return this;
    }

    undo() {
      if (!this._previous) return false;
      Object.assign(this, copy(this._previous));
      this._previous = null;
      return true;
    }

    snapshot() { return { ...copy(this), undo: this._previous ? copy(this._previous) : null }; }

    _swap(index) {
      this.board[this.blank] = this.board[index];
      this.board[index] = 0;
      this.blank = index;
    }

    _sample() {
      try {
        const value = Number(this.random());
        return Number.isFinite(value) ? Math.max(0, Math.min(1 - Number.EPSILON, value)) : 0;
      } catch { return 0; }
    }

    _tileDistance(value, index) {
      const goal = value - 1;
      return Math.abs(Math.floor(index / this.size) - Math.floor(goal / this.size)) + Math.abs(index % this.size - goal % this.size);
    }

    _distance() { return this.board.reduce((total, value, index) => total + (value ? this._tileDistance(value, index) : 0), 0); }

    static _readState(state) {
      try {
        if (!state || typeof state !== "object" || !validSize(state.size) || !Array.isArray(state.board) ||
            state.board.length !== state.size * state.size || !Number.isSafeInteger(state.steps) || state.steps < 0) return null;
        const size = state.size, board = state.board.slice(), seen = new Uint8Array(board.length);
        let blank = -1, inversions = 0;
        for (let index = 0; index < board.length; index++) {
          const value = board[index];
          if (!Number.isInteger(value) || value < 0 || value >= board.length || seen[value]) return null;
          seen[value] = 1;
          if (value === 0) blank = index;
          else for (let next = index + 1; next < board.length; next++) if (board[next] && board[next] < value) inversions++;
        }
        const solvable = size % 2 ? inversions % 2 === 0 : (inversions + size - Math.floor(blank / size)) % 2 === 1;
        if (!solvable) return null;
        return { size, board, blank, steps: state.steps, status: solved(board) ? "won" : state.steps > 0 ? "playing" : "ready" };
      } catch { return null; }
    }
  }

  global.SlidingPuzzle = SlidingPuzzle;
  if (typeof module !== "undefined" && module.exports) module.exports = { SlidingPuzzle };
})(typeof globalThis !== "undefined" ? globalThis : window);
