/* 游戏共享桌面；切换只改变焦点与暂停状态，不重置棋局。 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id), windows={minesweeper:$('game-window'),'2048':$('game2048-window'),huarong:$('huarong-window'),gomoku:$('gomoku-window'),xiangqi:$('xiangqi-window')};
  const taskButtons={minesweeper:$('task-button'),'2048':$('task2048-button'),huarong:$('taskhuarong-button'),gomoku:$('taskgomoku-button'),xiangqi:$('taskxiangqi-button')};
  const names={minesweeper:'扫雷','2048':'2048',huarong:'数字华容道',gomoku:'双人五子棋',xiangqi:'中国象棋'};
  const order=['minesweeper','2048','huarong','gomoku','xiangqi'];
  const tips={minesweeper:'左键翻开 · 右键插旗 · 单击数字快速展开','2048':'方向键 / WASD 移动 · 相同数字合并 · 拼出 2048',huarong:'点击相邻数字 · 拖入空格 · 方向键移动空格',gomoku:'黑棋先行 · 双人轮流落子 · 五子相连获胜',xiangqi:'红方先行 · 选棋查看落点 · 双人同屏对弈'};
  let active=null,last='minesweeper';
  try {const saved=localStorage.getItem('win7-desktop-active');if(order.includes(saved))last=saved;} catch {}
  function show(game) {
    if(game!==null && !windows[game])return;
    if(document.querySelector('dialog[open]'))return;
    active=game;
    for(const [key,window] of Object.entries(windows)) {
      window.hidden=key!==game;taskButtons[key].classList.toggle('active',key===game);
      taskButtons[key].setAttribute('aria-pressed',String(key===game));
    }
    document.body.dataset.activeGame=game||'desktop';
    document.querySelectorAll('[data-open-game]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.openGame===game)));
    $('restore-hint').hidden=game!==null;
    const tip=document.querySelector('.desktop-tip');tip.hidden=game===null;
    tip.textContent=tips[game]||'';
    window.MinesweeperDesktop.setActive(game==='minesweeper');
    if(game) {last=game;document.title=`${names[game]} · 经典小游戏桌面`;try{localStorage.setItem('win7-desktop-active',game);}catch{}}
    document.dispatchEvent(new CustomEvent('desktop:gamechange',{detail:{game}}));
  }
  document.querySelectorAll('[data-open-game]').forEach(button=>button.addEventListener('click',()=>show(button.dataset.openGame)));
  Object.entries(taskButtons).forEach(([game,button])=>button.addEventListener('click',()=>show(active===game?null:game)));
  document.querySelectorAll('[data-desktop-minimize]').forEach(button=>button.addEventListener('click',()=>show(null)));
  $('show-desktop').addEventListener('click',()=>show(null));
  $('start-button').addEventListener('click',()=>show(active===null?last:order[(order.indexOf(active)+1)%order.length]));
  $('restore').addEventListener('click',()=>show(last));
  document.addEventListener('desktop:open',event=>show(event.detail?.game));
  document.addEventListener('desktop:minimize',event=>{if(event.detail?.game===active)show(null);});
  window.DesktopGames={show,get active(){return active;}};
  show(last);
})();
