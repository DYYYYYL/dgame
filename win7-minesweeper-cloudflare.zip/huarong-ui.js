/* 数字华容道：本地输入、模型处理、稳定数字视图、CSV 记录导出。 */
(() => {
  "use strict";
  const $ = id => document.getElementById(id), win = $("huarong-window");
  if (!win || typeof SlidingPuzzle !== "function") return;
  const KEY = "win7-huarong-v1", board = $("hr-board"), overlay = $("hr-overlay"), nodes = new Map();
  const read = () => { try { const value = JSON.parse(localStorage.getItem(KEY)); return value && typeof value === "object" ? value : {}; } catch { return {}; } };
  const saved = read(), validTime = value => Number.isFinite(value) && value >= 0;
  let game;
  try { game = new SlidingPuzzle({ state: saved.state }); } catch { game = new SlidingPuzzle(); }
  const restored = saved.state?.size === game.size && Array.isArray(saved.state?.board) && saved.state.board.length === game.board.length && game.board.every((value, index) => saved.state.board[index] === value);
  let elapsed = restored && validTime(saved.elapsedMs) ? saved.elapsedMs : 0, anchor = null;
  let active = false, blurred = false, overlayKind = null, pendingSize = game.size, returnFocus = null;
  let drag = null, animations = [], generation = 0, terminalTimer = null, storageOK = true, lastPersist = 0;
  let recorded = game.status === "won" || game.steps > 0 && saved.recorded === true;
  const pointers = new Set(), bests = {};
  for (let size = 3; size <= 10; size++) {
    const record = saved.bests?.[size];
    if (record && Number.isInteger(record.steps) && record.steps >= 0 && validTime(record.elapsedMs)) bests[size] = { steps: record.steps, elapsedMs: record.elapsedMs, date: record.date || "" };
  }
  let history = Array.isArray(saved.history) ? saved.history.filter(row => row && Number.isInteger(row.size) && row.size >= 3 && row.size <= 10 && Number.isInteger(row.steps) && row.steps >= 0 && validTime(row.elapsedMs)).slice(-500) : [];
  $("hr-hints").checked = saved.hints === true;
  const elapsedNow = () => elapsed + (anchor === null ? 0 : performance.now() - anchor);
  const formatTime = value => { const tenths = Math.floor(Math.max(0, value) / 100); return `${String(Math.floor(tenths / 600)).padStart(2, "0")}:${String(Math.floor(tenths / 10) % 60).padStart(2, "0")}.${tenths % 10}`; };
  function clock() {
    const running = active && !blurred && !document.hidden && !overlayKind && game.status === "playing" && !document.querySelector("dialog[open]");
    if (running && anchor === null) anchor = performance.now();
    if (!running && anchor !== null) { elapsed += performance.now() - anchor; anchor = null; }
    $("hr-time").textContent = formatTime(elapsedNow());
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify({ state: game.snapshot(), elapsedMs: elapsedNow(), bests, history, recorded, hints: $("hr-hints").checked })); storageOK = true; }
    catch { storageOK = false; }
    lastPersist = performance.now();
  }
  function animate(element, frames, options) {
    if (!element?.animate || window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
    const animation = element.animate(frames, options); animation.finished.catch(() => {}); animations.push(animation);
  }
  function cancelTerminal() { clearTimeout(terminalTimer); terminalTimer = null; }
  function finishMotion() { cancelTerminal(); generation++; animations.forEach(animation => animation.cancel()); animations = []; }
  function render() {
    const validValues = new Set(game.board.filter(Boolean));
    for (const [value, element] of nodes) if (!validValues.has(value)) { element.remove(); nodes.delete(value); }
    game.board.forEach((value, index) => {
      if (!value) return;
      let tile = nodes.get(value);
      if (!tile) { tile = document.createElement("button"); tile.type = "button"; tile.className = "hr-tile"; tile.dataset.value = value; tile.textContent = value; nodes.set(value, tile); board.append(tile); }
      tile.dataset.index = index; tile.dataset.movable = game.canMove(index); tile.dataset.correct = index === value - 1;
      tile.style.width = tile.style.height = `calc(${100 / game.size}% - 4px)`;
      tile.style.left = `calc(${index % game.size * 100 / game.size}% + 2px)`;
      tile.style.top = `calc(${Math.floor(index / game.size) * 100 / game.size}% + 2px)`;
      tile.style.fontSize = `${Math.max(12, 33 - game.size * 2)}px`;
      tile.setAttribute("aria-label", `${value}，第 ${Math.floor(index / game.size) + 1} 行，第 ${index % game.size + 1} 列${game.canMove(index) ? "，可移动" : ""}`);
      tile.tabIndex = -1;
    });
    board.classList.toggle("hr-show-hints", $("hr-hints").checked);
    board.dataset.size = game.size; board.dataset.steps = game.steps; board.dataset.status = game.status; board.dataset.blank = game.blank;
    $("hr-steps").textContent = game.steps; $("hr-size").value = game.size;
    $("hr-size-label").textContent = $("hr-size-badge").textContent = `${game.size} × ${game.size}`;
    $("hr-undo").disabled = !game.canUndo;
    const best = bests[game.size]; $("hr-best").textContent = best ? `本阶最佳：${best.steps} 步 · ${formatTime(best.elapsedMs)}` : "本阶最佳：暂无记录";
    $("hr-status").textContent = !storageOK ? "本地存储不可用，本局仍可正常游玩" : game.status === "won" ? "所有数字都已归位，挑战成功！" : game.status === "ready" ? "移动空格旁的数字开始计时" : "按从左到右、从上到下的顺序排列数字";
    clock();
  }
  function focusBoard() { if (active && !win.hidden) board.focus({ preventScroll: true }); }
  function showOverlay(kind) {
    cancelTerminal(); cancelDrag(false);
    if (!overlayKind) returnFocus = document.activeElement;
    overlayKind = kind; clock(); save();
    const best = bests[game.size], messages = {
      confirm: ["↻", "重新打乱棋盘？", `将开始 ${pendingSize} × ${pendingSize} 的新挑战。\n当前进度会被替换，历史最佳会保留。`, "重新打乱", "继续当前局"],
      help: ["15", "如何玩数字华容道", "点击空格旁的数字，或沿空格方向拖入。\n从左到右、从上到下排成 1、2、3…，\n让空格留在右下角，即可完成。\n方向键移动空格，F2 重新打乱。\n切换游戏时计时暂停，可撤销上一步。", "知道了", ""],
      won: ["✓", "所有数字，顺利归位！", `${game.size} × ${game.size} · ${game.steps} 步 · ${formatTime(elapsedNow())}\n${best ? `本阶最佳：${best.steps} 步 · ${formatTime(best.elapsedMs)}` : "挑战完成！"}`, "再来一局", game.canUndo ? "撤销最后一步" : ""]
    };
    const [icon, title, text, primary, secondary] = messages[kind];
    $("hr-overlay-icon").textContent = icon; $("hr-overlay-title").textContent = title; $("hr-overlay-text").textContent = text;
    $("hr-overlay-primary").textContent = primary; $("hr-overlay-secondary").textContent = secondary; $("hr-overlay-secondary").hidden = !secondary;
    overlay.hidden = false;
    if (active) $("hr-overlay-primary").focus({ preventScroll: true });
  }
  function hideOverlay() {
    overlayKind = null; overlay.hidden = true; clock();
    if (active) {
      if (returnFocus && win.contains(returnFocus) && !overlay.contains(returnFocus) && !returnFocus.disabled) returnFocus.focus({ preventScroll: true });
      else focusBoard();
    }
    returnFocus = null;
  }
  function terminal(delay = 0) {
    cancelTerminal();
    if (game.status !== "won" || !active || blurred || document.hidden || overlayKind) return;
    if (!delay) { showOverlay("won"); return; }
    const token = generation;
    terminalTimer = setTimeout(() => { terminalTimer = null; if (token === generation && active && !blurred && !document.hidden && !overlayKind) showOverlay("won"); }, delay);
  }
  function recordWin() {
    const record = { date: new Date().toISOString(), size: game.size, steps: game.steps, elapsedMs: elapsedNow() }, best = bests[game.size];
    if (!best || record.steps < best.steps || record.steps === best.steps && record.elapsedMs < best.elapsedMs) bests[game.size] = { steps: record.steps, elapsedMs: record.elapsedMs, date: record.date };
    if (!recorded) { history.push(record); history = history.slice(-500); recorded = true; }
  }
  const playable = () => active && !win.hidden && !blurred && !document.hidden && !overlayKind && game.status !== "won" && !document.querySelector("dialog[open]");
  function processMove(change, offset = { x: 0, y: 0 }) {
    if (!change.changed) return;
    clock(); if (game.status === "won") recordWin();
    save(); render();
    const step = board.clientWidth / game.size, element = nodes.get(change.value);
    const dx = (change.from % game.size - change.to % game.size) * step + offset.x;
    const dy = (Math.floor(change.from / game.size) - Math.floor(change.to / game.size)) * step + offset.y;
    animate(element, [{ transform: `translate(${dx}px,${dy}px)` }, { transform: "translate(0,0)" }], { duration: 130, easing: "cubic-bezier(.2,.7,.25,1)" });
    terminal(220);
  }
  function move(index, offset) { if (!playable()) return; finishMotion(); processMove(game.move(index), offset); }
  function cancelDrag(rebound = true) {
    if (!drag) return;
    const gesture = drag; drag = null;
    try { if (gesture.element.hasPointerCapture?.(gesture.id)) gesture.element.releasePointerCapture(gesture.id); } catch {}
    gesture.element.style.transform = ""; gesture.element.classList.remove("hr-dragging");
    if (rebound && gesture.delta) animate(gesture.element, [{ transform: `translate(${gesture.axis === "x" ? gesture.delta : 0}px,${gesture.axis === "y" ? gesture.delta : 0}px)` }, { transform: "translate(0,0)" }], { duration: 110, easing: "ease-out" });
  }
  function shuffle(size = game.size) {
    cancelDrag(false); finishMotion(); anchor = null; elapsed = 0; recorded = false;
    game.shuffle(size); pendingSize = game.size; hideOverlay(); save(); render(); focusBoard();
  }
  function requestShuffle(size = game.size) {
    if (!Number.isInteger(size) || size < 3 || size > 10) return;
    cancelDrag(false); finishMotion(); pendingSize = size;
    if (game.steps > 0 && game.status !== "won") showOverlay("confirm"); else shuffle(size);
  }
  function undo() {
    cancelDrag(false); finishMotion(); clock();
    if (!game.undo()) { terminal(); return false; }
    hideOverlay(); save(); render(); focusBoard(); return true;
  }
  function exportCSV() {
    const rows = history.map(row => [row.date, row.size, row.steps, (row.elapsedMs / 1000).toFixed(3), "won"]);
    if (game.status !== "won" || !recorded) rows.push([new Date().toISOString(), game.size, game.steps, (elapsedNow() / 1000).toFixed(3), game.status]);
    const quote = value => `"${String(value).replaceAll('"', '""')}"`;
    const csv = "\uFEFF" + [["date", "size", "steps", "timeSeconds", "status"], ...rows].map(row => row.map(quote).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" })), link = document.createElement("a");
    link.href = url; link.download = `数字华容道-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const actions = { new: () => requestShuffle(), undo, help: () => showOverlay("help"), export: exportCSV };
  win.querySelectorAll("[data-hr-action]").forEach(button => button.addEventListener("click", () => actions[button.dataset.hrAction]()));
  $("hr-size").addEventListener("input", event => { $("hr-size-label").textContent = `${event.target.value} × ${event.target.value}`; });
  $("hr-size").addEventListener("change", event => requestShuffle(Number(event.target.value)));
  $("hr-hints").addEventListener("change", () => { save(); render(); });
  $("hr-overlay-primary").addEventListener("click", () => {
    if (overlayKind === "confirm") shuffle(pendingSize);
    else if (overlayKind === "won") shuffle();
    else { hideOverlay(); terminal(); save(); }
  });
  $("hr-overlay-secondary").addEventListener("click", () => {
    if (overlayKind === "confirm") { hideOverlay(); render(); terminal(); save(); }
    else undo();
  });
  const tileAt = target => { const tile = target.closest?.(".hr-tile"); return tile && board.contains(tile) ? tile : null; };
  board.addEventListener("pointerdown", event => {
    if (!playable() || event.button > 0 || event.isPrimary === false || pointers.size > 1) { cancelDrag(); return; }
    const element = tileAt(event.target), index = element ? Number(element.dataset.index) : -1;
    if (!game.canMove(index)) return;
    cancelDrag(false); finishMotion();
    const dr = Math.floor(game.blank / game.size) - Math.floor(index / game.size), dc = game.blank % game.size - index % game.size;
    drag = { id: event.pointerId, element, index, x: event.clientX, y: event.clientY, lastX: event.clientX, lastY: event.clientY, travel: 0, axis: dc ? "x" : "y", sign: dc || dr, step: board.clientWidth / game.size, delta: 0 };
    element.classList.add("hr-dragging");
    try { element.setPointerCapture(event.pointerId); } catch {}
  });
  function updateDrag(event) {
    if (!drag || drag.id !== event.pointerId) return;
    drag.travel += Math.hypot(event.clientX - drag.lastX, event.clientY - drag.lastY); drag.lastX = event.clientX; drag.lastY = event.clientY;
    const raw = drag.axis === "x" ? event.clientX - drag.x : event.clientY - drag.y;
    drag.delta = drag.sign * Math.max(0, Math.min(drag.step, raw * drag.sign));
    drag.element.style.transform = `translate(${drag.axis === "x" ? drag.delta : 0}px,${drag.axis === "y" ? drag.delta : 0}px)`;
  }
  board.addEventListener("pointermove", updateDrag);
  board.addEventListener("pointerup", event => {
    if (!drag || drag.id !== event.pointerId) return;
    updateDrag(event);
    const gesture = drag, commit = Math.abs(gesture.delta) >= gesture.step * .2 || gesture.travel < 5;
    const offset = { x: gesture.axis === "x" ? gesture.delta : 0, y: gesture.axis === "y" ? gesture.delta : 0 };
    cancelDrag(!commit); if (commit) move(gesture.index, offset);
  });
  board.addEventListener("lostpointercapture", event => { if (drag?.id === event.pointerId) cancelDrag(); });
  board.addEventListener("click", event => {
    if (event.detail !== 0 || event.sourceCapabilities?.firesTouchEvents || event.pointerType && event.pointerType !== "mouse") return;
    const tile = tileAt(event.target); if (tile) { cancelDrag(false); move(Number(tile.dataset.index)); }
  });
  board.addEventListener("contextmenu", event => event.preventDefault());
  document.addEventListener("pointerdown", event => {
    if (event.pointerType !== "mouse") pointers.add(event.pointerId);
    if (pointers.size > 1 || drag && drag.id !== event.pointerId) cancelDrag();
  }, true);
  document.addEventListener("pointerup", event => pointers.delete(event.pointerId), true);
  document.addEventListener("pointercancel", event => { pointers.delete(event.pointerId); if (drag?.id === event.pointerId) cancelDrag(); }, true);
  document.addEventListener("keydown", event => {
    if (!active || win.hidden || event.ctrlKey || event.altKey || event.metaKey || event.target.closest?.("input,select,textarea,[contenteditable='true']") || document.querySelector("dialog[open]")) return;
    if (overlayKind) { if (event.key === "Escape" && overlayKind !== "won") { event.preventDefault(); hideOverlay(); render(); terminal(); save(); } return; }
    const direction = { ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down" }[event.key];
    if (direction) { event.preventDefault(); if (playable()) { cancelDrag(false); finishMotion(); processMove(game.moveBlank(direction)); } }
    else if (event.key === "F2") { event.preventDefault(); requestShuffle(); }
    else if (event.key === "F1") { event.preventDefault(); showOverlay("help"); }
  });
  const maximize = () => { cancelDrag(false); finishMotion(); win.classList.toggle("maximized"); $("hr-maximize").title = win.classList.contains("maximized") ? "还原数字华容道窗口" : "最大化数字华容道"; $("hr-maximize").setAttribute("aria-label", $("hr-maximize").title); terminal(); };
  $("hr-maximize").addEventListener("click", maximize);
  $("hr-titlebar").addEventListener("dblclick", event => { if (!event.target.closest("button")) maximize(); });
  document.addEventListener("desktop:gamechange", event => {
    cancelDrag(false); pointers.clear(); finishMotion(); active = event.detail?.game === "huarong"; clock(); save();
    if (active) { if (overlayKind) $("hr-overlay-primary").focus({ preventScroll: true }); else terminal(); }
  });
  window.addEventListener("blur", () => { blurred = true; cancelDrag(false); pointers.clear(); finishMotion(); clock(); save(); });
  window.addEventListener("focus", () => { blurred = false; clock(); terminal(); });
  window.addEventListener("resize", () => { cancelDrag(false); pointers.clear(); finishMotion(); terminal(); });
  document.addEventListener("visibilitychange", () => { cancelDrag(false); pointers.clear(); finishMotion(); clock(); save(); if (!document.hidden) terminal(); });
  window.addEventListener("pagehide", () => { if (anchor !== null) { elapsed += performance.now() - anchor; anchor = null; } save(); });
  window.addEventListener("pageshow", clock);
  window.HuarongUI = { newGame: requestShuffle, undo, exportCSV, snapshot: () => ({ state: game.snapshot(), elapsedMs: elapsedNow(), bests: structuredClone(bests) }), open: () => document.dispatchEvent(new CustomEvent("desktop:open", { detail: { game: "huarong" } })) };
  save(); render();
  setInterval(() => { clock(); if (anchor !== null && performance.now() - lastPersist >= 1000) save(); }, 100);
})();
