/* 数据输入与持久化 → 游戏模型 → 界面交互 → CSV 结果导出。 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const PRESETS = {beginner:{rows:9,cols:9,mines:10,label:'初级'},intermediate:{rows:16,cols:16,mines:40,label:'中级'},expert:{rows:16,cols:30,mines:99,label:'高级'}};
  const LABELS = {...Object.fromEntries(Object.entries(PRESETS).map(([key,value]) => [key,value.label])),custom:'自定义'};
  const KEY = 'win7-minesweeper-v1';
  const load = () => {try{return JSON.parse(localStorage.getItem(KEY)) || {};}catch{return {};}};
  const saved = load(), validNumber = (n,min,max,fallback) => Number.isInteger(n) && n >= min && n <= max ? n : fallback;
  const p = saved.preferences || {};
  let preferences = {difficulty:LABELS[p.difficulty] ? p.difficulty : 'beginner',rows:validNumber(p.rows,9,24,9),cols:validNumber(p.cols,9,40,9),mines:validNumber(p.mines,1,951,10),theme:p.theme === 'green' ? 'green':'blue',questionMarks:p.questionMarks !== false,sound:p.sound === true};
  preferences.mines = Math.min(preferences.mines,preferences.rows*preferences.cols-9);
  const emptyStats = () => ({played:0,wins:0,best:null,streak:0,bestStreak:0});
  let statistics = Object.fromEntries(Object.keys(LABELS).map(key => {
    const s = saved.statistics?.[key] || {}, clean = emptyStats();
    for (const prop of ['played','wins','streak','bestStreak']) clean[prop] = validNumber(s[prop],0,1e9,0);
    clean.wins = Math.min(clean.wins,clean.played);
    clean.best = typeof s.best === 'number' && Number.isFinite(s.best) && s.best >= 0 ? s.best : null;
    return [key,clean];
  }));
  let history = Array.isArray(saved.history) ? saved.history.filter(x => x && LABELS[x.difficulty] && ['won','lost','abandoned'].includes(x.result) && Number.isFinite(x.seconds)).slice(-500) : [];
  const persist = () => {try{localStorage.setItem(KEY,JSON.stringify({preferences,statistics,history}));}catch{$('status-text').textContent='浏览器存储不可用，本局仍可正常游玩';}};
  const configuration = settings => settings.difficulty === 'custom' ? {rows:settings.rows,cols:settings.cols,mines:settings.mines} : PRESETS[settings.difficulty];
  let game, difficulty, recorded=false, elapsed=0, anchor=null, focused=0, flagMode=false, pendingSettings=null, audio;
  let inputController=null, cellButtons=[], pressedCells=[], resultTimer=null, resultPending=false;
  const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
  const pauses = new Set();
  const seconds = () => Math.floor((elapsed+(anchor===null?0:performance.now()-anchor))/1000);
  function clock() {
    const running = game?.status === 'playing' && !pauses.size;
    if (running && anchor === null) anchor=performance.now();
    if (!running && anchor !== null) {elapsed+=performance.now()-anchor;anchor=null;}
    const time=String(seconds());if($('timer').textContent!==time)$('timer').textContent=time;
  }
  function setPause(reason,value) {
    value ? pauses.add(reason) : pauses.delete(reason);
    if(value)inputController?.reset();
    clock();
    const covered = game.status === 'playing' && [...pauses].some(x => x !== 'dialog');
    $('pause-overlay').hidden=!covered;
    $('pause-menu-label').textContent=pauses.has('manual')?'继续游戏':'暂停游戏';
    $('board').setAttribute('aria-disabled',String(!!pauses.size));
  }
  function canInteract() {
    // dialog.close 的 close 事件可能下一帧才送达；实际已关闭时立即恢复输入。
    if(pauses.has('dialog') && !document.querySelector('dialog[open]'))setPause('dialog',false);
    return !$('game-window').hidden && !pauses.size && ['ready','playing'].includes(game.status);
  }
  function sound(kind) {
    if (!preferences.sound) return;
    try {
      audio ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === 'suspended') audio.resume().catch(()=>{});
      const notes = kind==='won'?[523,659,784,1047]:kind==='lost'?[160,110,75]:kind==='flag'?[540]:[680];
      notes.forEach((frequency,i) => {
        const oscillator=audio.createOscillator(), gain=audio.createGain(), start=audio.currentTime+i*.11;
        oscillator.type=kind==='lost'?'triangle':'sine';oscillator.frequency.setValueAtTime(frequency,start);
        gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(.055,start+.008);gain.gain.exponentialRampToValueAtTime(.0001,start+.16);
        oscillator.connect(gain);gain.connect(audio.destination);oscillator.start(start);oscillator.stop(start+.17);
      });
    } catch {/* 声音不受支持时保留完整游戏功能。 */}
  }
  function record(result) {
    if (recorded || !game || game.status==='ready') return;
    recorded=true;
    const s=statistics[difficulty], time=seconds();s.played++;
    if (result==='won') {s.wins++;s.streak++;s.bestStreak=Math.max(s.streak,s.bestStreak);s.best=s.best===null?time:Math.min(s.best,time);} else s.streak=0;
    history.push({date:new Date().toISOString(),difficulty,rows:game.rows,cols:game.cols,mines:game.mines,result,seconds:time});
    history=history.slice(-500);persist();
  }
  const icon = name => `<svg aria-hidden="true"><use href="#icon-${name}"/></svg>`;
  function drawCell(index,origin=null) {
    const c=game.cells[index], button=cellButtons[index], ended=['won','lost'].includes(game.status);
    const showMine=game.status==='lost' && c.mine && c.mark!==1, wrong=game.status==='lost' && c.mark===1 && !c.mine;
    const key=`${c.revealed}:${c.mark}:${showMine}:${wrong}:${game.exploded===index}`;
    button.setAttribute('aria-disabled',String(ended));
    if(button.dataset.renderKey===key)return;
    const distance=origin===null?Infinity:Math.max(Math.abs(Math.floor(index/game.cols)-Math.floor(origin/game.cols)),Math.abs(index%game.cols-origin%game.cols));
    const previous=button.dataset.state, reveal=distance<=5 && previous!=='revealed' && c.revealed && !c.mine;
    const flag=origin!==null && previous!=='flagged' && !c.revealed && c.mark===1;
    button.dataset.renderKey=key;
    button.className=['cell',c.revealed?'revealed':'',c.revealed&&!c.mine?`number-${c.adjacent}`:'',c.mark===2&&!c.revealed?'question':'',showMine?'mine-shown':'',game.exploded===index?'exploded':'',wrong?'wrong':'',reveal?'revealing':'',flag?'flag-set':''].filter(Boolean).join(' ');
    if(reveal)button.style.setProperty('--wave-delay',`${distance*12}ms`);
    let label='未翻开';
    if(showMine || c.revealed&&c.mine) {button.innerHTML=icon('mine');label='地雷';}
    else if(c.revealed) {button.innerHTML=c.adjacent?`<span class="cell-content">${c.adjacent}</span>`:'';label=c.adjacent?`周围 ${c.adjacent} 个雷`:'空白';}
    else if(c.mark===1) {button.innerHTML=icon('flag');label=wrong?'错误旗帜':'已插旗';}
    else if(c.mark===2) {button.textContent='?';label='问号';}
    else button.textContent='';
    button.dataset.state=c.revealed?'revealed':c.mark===1?'flagged':c.mark===2?'question':'covered';
    button.setAttribute('aria-label',`第 ${Math.floor(index/game.cols)+1} 行，第 ${index%game.cols+1} 列，${label}`);
  }
  function render(changed=null,origin=null) {
    if(changed) changed.forEach(i=>drawCell(i,origin));else game.cells.forEach((_,i)=>drawCell(i,origin));
    $('mine-count').textContent=game.mines-game.flags;
    $('board').dataset.status=game.status;
    $('status-text').textContent=game.status==='ready'?'单击任意方格开始游戏':game.status==='won'?'恭喜，雷区已成功清除！':game.status==='lost'?'触到地雷了，再试一次吧':`${LABELS[difficulty]} · 已翻开 ${game.revealed} / ${game.rows*game.cols-game.mines} 个安全格`;
  }
  function fitBoard() {
    if(!game || $('game-window').hidden)return;
    const desktopStyle=getComputedStyle($('desktop'));
    const chrome=$('game-window').offsetHeight-$('board-scroller').offsetHeight;
    const room=Math.max(180,innerHeight-document.querySelector('.taskbar').offsetHeight-parseFloat(desktopStyle.paddingTop)-parseFloat(desktopStyle.paddingBottom)-parseFloat(desktopStyle.rowGap)-document.querySelector('.desktop-tip').offsetHeight-chrome-8);
    let tile=Math.min(game.rows>9?28:34,Math.floor((room-6)/game.rows));
    if(game.cols<=9)tile=Math.min(tile,Math.floor((innerWidth-64)/game.cols));
    if($('game-window').classList.contains('maximized')) tile=Math.min(42,Math.floor((room-6)/game.rows));
    $('game-window').style.setProperty('--tile',`${Math.max(22,tile)}px`);
    $('board-scroller').style.maxHeight=`${room}px`;
  }
  function start(settings=preferences) {
    clearTimeout(resultTimer);resultTimer=null;resultPending=false;inputController?.reset();
    $('board').classList.remove('board-won','board-lost');
    if(game?.status==='playing')record('abandoned');
    preferences={...settings};difficulty=preferences.difficulty;persist();
    game=new MinesweeperGame(configuration(preferences));recorded=false;elapsed=0;anchor=null;focused=0;pauses.delete('manual');
    document.body.classList.toggle('theme-green',preferences.theme==='green');
    const board=$('board');board.style.setProperty('--cols',game.cols);board.setAttribute('aria-rowcount',game.rows);board.setAttribute('aria-colcount',game.cols);
    board.innerHTML=game.cells.map((_,i)=>`<button class="cell" role="gridcell" data-index="${i}" tabindex="${i===0?0:-1}" aria-rowindex="${Math.floor(i/game.cols)+1}" aria-colindex="${i%game.cols+1}"></button>`).join('');
    cellButtons=Array.from(board.children);
    $('difficulty-label').textContent=`${LABELS[difficulty]} · ${game.rows} × ${game.cols}`;
    $('board-scroller').scrollLeft=0;fitBoard();render();setPause('manual',false);clock();
  }
  function openDialog(id) {clearTimeout(resultTimer);resultTimer=null;if(id!=='result-dialog')resultPending=false;closeMenus();setPause('dialog',true);$(id).showModal();}
  function requestNew(settings=preferences) {
    closeMenus();pendingSettings={...settings};
    if(game.status==='playing')openDialog('confirm-dialog');else start(pendingSettings);
  }
  function resultDialog() {
    resultPending=false;
    const won=game.status==='won', best=statistics[difficulty].best;
    $('result-title').textContent=won?'游戏胜利':'游戏结束';
    $('result-icon').innerHTML=won?'⚑':icon('mine');
    $('result-heading').textContent=won?'恭喜，你赢了！':'很遗憾，你触雷了';
    $('result-message').textContent=won?'所有安全方格均已翻开。出色的排雷！':'再来一局，下一步也许就能找到答案。';
    $('result-time').textContent=`${seconds()} 秒`;$('result-best').textContent=best===null?'—':`${best} 秒`;
    openDialog('result-dialog');
  }
  function scheduleResult() {
    clearTimeout(resultTimer);
    resultTimer=setTimeout(()=>{resultTimer=null;if(resultPending && ['won','lost'].includes(game.status) && !$('game-window').hidden && !document.querySelector('dialog[open]'))resultDialog();},reducedMotion.matches?120:380);
  }
  function act(type,index) {
    if(!canInteract() || !Number.isInteger(index))return;
    const change=type==='flag'?game.cycleMark(index,preferences.questionMarks):type==='chord'?game.chord(index):game.reveal(index);
    if(!change.changed.length)return;
    focusCell(index,false);clock();
    if(change.ended) {
      record(game.status);render(null,index);sound(game.status);inputController?.reset();
      $('board').classList.add(`board-${game.status}`);
      resultPending=true;scheduleResult();
    }
    else {render(change.changed,index);sound(type==='flag'?'flag':'reveal');}
  }
  function closeMenus() {
    ['game','help'].forEach(key=>{$(`${key}-menu`).hidden=true;$(`${key}-menu-trigger`).setAttribute('aria-expanded','false');});
  }
  function openMenu(key) {
    const wasOpen=!$(`${key}-menu`).hidden;closeMenus();
    if(!wasOpen){$(`${key}-menu`).hidden=false;$(`${key}-menu-trigger`).setAttribute('aria-expanded','true');}
  }
  function showOptions() {
    const form=$('options-form');form.elements.difficulty.value=preferences.difficulty;
    for(const name of ['rows','cols','mines','theme'])form.elements[name].value=preferences[name];
    for(const name of ['questionMarks','sound'])form.elements[name].checked=preferences[name];
    $('options-error').textContent='';updateCustom();openDialog('options-dialog');
  }
  function updateCustom() {
    const form=$('options-form'),custom=form.elements.difficulty.value==='custom';
    for(const name of ['rows','cols','mines'])form.elements[name].disabled=!custom;
  }
  function showStats(key=difficulty) {
    const s=statistics[key];
    document.querySelectorAll('[data-stats]').forEach(button=>{button.setAttribute('aria-selected',String(button.dataset.stats===key));button.tabIndex=button.dataset.stats===key?0:-1;});
    $('stats-content').innerHTML=`<div class="best-score"><span>最佳用时</span><strong>${s.best===null?'暂无记录':`${s.best} <small>秒</small>`}</strong></div>`+[['游戏局数',s.played],['获胜局数',s.wins],['获胜率',s.played?`${Math.round(s.wins/s.played*100)}%`:'0%'],['当前连胜',s.streak],['最长连胜',s.bestStreak]].map(([label,value])=>`<div class="stat-row"><span>${label}</span><strong>${value}</strong></div>`).join('');
    if(!$('stats-dialog').open)openDialog('stats-dialog');
  }
  function minimize() {document.dispatchEvent(new CustomEvent('desktop:minimize',{detail:{game:'minesweeper'}}));}
  function togglePause() {if(game.status==='playing')setPause('manual',!pauses.has('manual'));closeMenus();}
  const actions={new:()=>requestNew(),pause:togglePause,options:showOptions,stats:()=>showStats(),exit:minimize,help:()=>openDialog('help-dialog'),about:()=>openDialog('about-dialog')};
  document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>{closeMenus();actions[b.dataset.action]();}));
  ['game','help'].forEach(key=>$(`${key}-menu-trigger`).addEventListener('click',()=>openMenu(key)));
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.menu-wrap'))closeMenus();});
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
  document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('close',()=>{if(!document.querySelector('dialog[open]'))setPause('dialog',false);}));
  $('restart').addEventListener('click',()=>requestNew());$('play-again').addEventListener('click',()=>{$('result-dialog').close();start();});
  $('confirm-new').addEventListener('click',()=>{$('confirm-dialog').close();start(pendingSettings);});
  $('resume').addEventListener('click',()=>setPause('manual',false));
  ['minimize','close-window'].forEach(id=>$(id).addEventListener('click',minimize));
  const maximize=()=>{$('game-window').classList.toggle('maximized');$('maximize').title=$('game-window').classList.contains('maximized')?'还原':'最大化';$('maximize').setAttribute('aria-label',$('maximize').title);fitBoard();};
  $('maximize').addEventListener('click',maximize);$('titlebar').addEventListener('dblclick',e=>{if(!e.target.closest('button'))maximize();});
  $('touch-mode').addEventListener('click',()=>{flagMode=!flagMode;$('touch-mode').setAttribute('aria-pressed',String(flagMode));$('touch-mode').querySelector('span').textContent=`插旗模式：${flagMode?'开':'关'}`;});
  $('options-form').addEventListener('change',updateCustom);
  $('options-form').addEventListener('submit',e=>{
    e.preventDefault();const f=e.currentTarget.elements;
    const next={difficulty:f.difficulty.value,rows:Number(f.rows.value),cols:Number(f.cols.value),mines:Number(f.mines.value),theme:f.theme.value,questionMarks:f.questionMarks.checked,sound:f.sound.checked};
    if(next.difficulty==='custom' && (![next.rows,next.cols,next.mines].every(Number.isInteger) || next.rows<9 || next.rows>24 || next.cols<9 || next.cols>40 || next.mines<1 || next.mines>next.rows*next.cols-9)) {$('options-error').textContent='请输入有效的整数，且至少保留 9 个安全格。';return;}
    const previous=configuration(preferences),current=configuration(next),sameBoard=next.difficulty===preferences.difficulty && ['rows','cols','mines'].every(key=>previous[key]===current[key]);
    $('options-dialog').close();
    if(sameBoard){preferences=next;document.body.classList.toggle('theme-green',next.theme==='green');persist();}else requestNew(next);
  });
  document.querySelectorAll('[data-stats]').forEach(b=>{
    b.addEventListener('click',()=>showStats(b.dataset.stats));
    b.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();const keys=Object.keys(LABELS),next=keys[(keys.indexOf(b.dataset.stats)+(e.key==='ArrowRight'?1:3))%4];showStats(next);document.querySelector(`[data-stats="${next}"]`).focus();});
  });
  // 只导出本地游戏结果；UTF-8 BOM 兼容 Excel 的中文显示。
  $('export-stats').addEventListener('click',()=>{
    const titles=['日期（本地时间）','难度','行数','列数','雷数','结果','用时（秒）'],names={won:'获胜',lost:'失败',abandoned:'未完成'};
    const quote=value=>`"${String(value).replaceAll('"','""')}"`;
    const csv='\uFEFF'+[titles,...history.map(h=>[new Date(h.date).toLocaleString('zh-CN'),LABELS[h.difficulty],h.rows,h.cols,h.mines,names[h.result],h.seconds])].map(row=>row.map(quote).join(',')).join('\r\n');
    const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'})),a=document.createElement('a');a.href=url;a.download=`扫雷记录-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  const board=$('board');
  const indexOf=event=>{const c=event.target.closest('.cell');return c?Number(c.dataset.index):null;};
  function preview(indices) {
    pressedCells.forEach(i=>cellButtons[i]?.classList.remove('pressed'));
    pressedCells=indices;
    pressedCells.forEach(i=>cellButtons[i]?.classList.add('pressed'));
  }
  inputController=bindMinesweeperInput(board,{
    cell:i=>game.cells[i],neighbors:i=>game.neighbors(i),
    enabled:canInteract,
    activate:(type,i)=>act(type==='reveal' && flagMode?'flag':type,i),
    preview,focus:i=>focusCell(i,false)
  });
  board.addEventListener('animationend',e=>{
    if(e.animationName==='tile-reveal'){e.target.classList.remove('revealing');e.target.style.removeProperty('--wave-delay');}
    if(e.animationName==='flag-plant')e.target.closest('.cell')?.classList.remove('flag-set');
  });
  function focusCell(i,move=true) {if(cellButtons[focused])cellButtons[focused].tabIndex=-1;focused=i;cellButtons[i].tabIndex=0;if(move)cellButtons[i].focus({preventScroll:false});}
  board.addEventListener('keydown',e=>{
    const i=indexOf(e);if(i===null)return;
    const row=Math.floor(i/game.cols),col=i%game.cols,moves={ArrowLeft:[row,Math.max(0,col-1)],ArrowRight:[row,Math.min(game.cols-1,col+1)],ArrowUp:[Math.max(0,row-1),col],ArrowDown:[Math.min(game.rows-1,row+1),col]};
    if(moves[e.key]){e.preventDefault();const [r,c]=moves[e.key];focusCell(r*game.cols+c);}
    else if(e.key.toLowerCase()==='f'){e.preventDefault();if(!e.repeat)act('flag',i);}
    else if(e.key===' ' || e.key==='Enter'){e.preventDefault();act(game.cells[i].revealed?'chord':'reveal',i);}
  });
  document.addEventListener('keydown',e=>{
    if($('game-window').hidden)return;
    if(e.key==='Escape'){closeMenus();return;}
    const menu=e.target.closest('.dropdown'),trigger=e.target.closest('.menu-trigger');
    if(['ArrowDown','ArrowUp'].includes(e.key) && (menu || trigger)) {
      e.preventDefault();if(trigger){const key=trigger.id.startsWith('game')?'game':'help';closeMenus();$(`${key}-menu`).hidden=false;trigger.setAttribute('aria-expanded','true');$(`${key}-menu`).querySelector('button').focus();}
      else {const items=[...menu.querySelectorAll('button')],i=items.indexOf(e.target);items[(i+(e.key==='ArrowDown'?1:items.length-1))%items.length].focus();}return;
    }
    if(e.altKey && ['g','h'].includes(e.key.toLowerCase())){e.preventDefault();openMenu(e.key.toLowerCase()==='g'?'game':'help');return;}
    if(e.target.matches('input,select,textarea') || document.querySelector('dialog[open]'))return;
    const hotkeys={F1:actions.help,F2:actions.new,F4:actions.stats,F5:actions.options,p:togglePause,P:togglePause};
    if(hotkeys[e.key]){e.preventDefault();hotkeys[e.key]();}
  });
  document.addEventListener('visibilitychange',()=>setPause('hidden',document.hidden));
  window.addEventListener('resize',fitBoard);
  const updateText=(id,value)=>{const node=$(id);if(node.textContent!==String(value))node.textContent=value;};
  function systemClock() {const now=new Date();updateText('system-time',now.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false}));updateText('system-date',`${now.getFullYear()}/${now.getMonth()+1}/${now.getDate()}`);}
  window.MinesweeperDesktop={setActive(active){
    if(!active){clearTimeout(resultTimer);resultTimer=null;closeMenus();}
    setPause('inactive',!active);if(active){fitBoard();if(resultPending)scheduleResult();}
  }};
  start();systemClock();setInterval(()=>{clock();systemClock();},250);
})();
