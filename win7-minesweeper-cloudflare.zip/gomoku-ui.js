/* 双人五子棋：本地进度 → 对弈模型 → 棋盘视图 → CSV 棋谱。 */
(() => {
  "use strict";
  const $ = id => document.getElementById(id), win = $("gomoku-window");
  if (!win || typeof Gomoku !== "function") return;
  const KEY = "win7-gomoku-v1", board = $("gm-board"), points = $("gm-points"), overlay = $("gm-overlay");
  const read = () => { try { const data = JSON.parse(localStorage.getItem(KEY)); return data && typeof data === "object" ? data : {}; } catch { return {}; } };
  const saved = read();
  let game;
  try { game = new Gomoku({ state: saved.state }); } catch { game = new Gomoku(); }
  let active = false, overlayKind = null, returnFocus = null, gesture = null, focused = 112;
  let animations = [], generation = 0, terminalTimer = null, storageOK = true;
  let terminalDismissed = game.status !== "playing" && saved.terminalDismissed === true;
  let started = Number.isFinite(Date.parse(saved.started)) ? saved.started : new Date().toISOString();
  const pointers = new Set(), playerName = player => player === 1 ? "黑方" : "白方";
  $("gm-grid-lines").setAttribute("d", Array.from({ length: 15 }, (_, n) => `M50 ${n * 100 + 50}H1450 M${n * 100 + 50} 50V1450`).join(" "));
  points.innerHTML = Array.from({ length: 225 }, (_, index) => `<button type="button" class="gm-cell gm-point" role="gridcell" data-index="${index}" data-player="0" aria-rowindex="${Math.floor(index / 15) + 1}" aria-colindex="${index % 15 + 1}" tabindex="${index === focused ? 0 : -1}"><span class="gm-stone" aria-hidden="true"></span></button>`).join("");
  const pointAt = target => { const point = target?.closest?.(".gm-point"); return point && points.contains(point) ? point : null; };
  function focusCell(index, move = true) {
    if (points.children[focused]) points.children[focused].tabIndex = -1;
    focused = index; points.children[index].tabIndex = 0;
    if (move && active && !win.hidden) points.children[index].focus({ preventScroll: true });
  }
  points.addEventListener("focusin", event => {
    const point = pointAt(event.target);
    if (point) focusCell(Number(point.dataset.index), false);
  });
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify({ state: game.snapshot(), started, terminalDismissed })); storageOK = true; }
    catch { storageOK = false; }
  }
  function render() {
    const last = game.moves.at(-1)?.index, winning = new Set(game.winningLine);
    game.board.forEach((player, index) => {
      const point = points.children[index]; point.dataset.player = player;
      point.classList.toggle("gm-last", index === last);
      point.classList.toggle("gm-winner", winning.has(index));
      point.setAttribute("aria-label", `第 ${Math.floor(index / 15) + 1} 行，第 ${index % 15 + 1} 列，${player ? `${playerName(player)}棋子${index === last ? "，最后一手" : ""}` : "空位"}${winning.has(index) ? "，获胜连线" : ""}`);
      point.setAttribute("aria-disabled", String(game.status !== "playing" || player !== 0));
    });
    board.dataset.status = game.status; board.dataset.turn = game.currentPlayer; board.dataset.moves = game.moves.length; board.dataset.winner = game.winner;
    $("gm-moves").textContent = game.moves.length; $("gm-undo").disabled = !game.canUndo;
    $("gm-turn-stone").dataset.player = game.status === "won" ? game.winner : game.currentPlayer;
    $("gm-turn-text").textContent = game.status === "won" ? `${playerName(game.winner)}获胜` : game.status === "draw" ? "本局和棋" : `轮到${playerName(game.currentPlayer)}落子`;
    $("gm-status").textContent = !storageOK ? "本地存储不可用，本局仍可正常游玩" : game.status === "won" ? `${playerName(game.winner)}已连成 ${game.winningLine.length} 子，恭喜！` : game.status === "draw" ? "棋盘已满，双方握手言和。" : "点击交叉点落子，和身边的人下一局。";
    const line = $("gm-winning-line");
    if (game.winningLine.length) {
      const start = game.winningLine[0], end = game.winningLine.at(-1);
      line.setAttribute("x1", start % 15 * 100 + 50); line.setAttribute("y1", Math.floor(start / 15) * 100 + 50);
      line.setAttribute("x2", end % 15 * 100 + 50); line.setAttribute("y2", Math.floor(end / 15) * 100 + 50); line.setAttribute("visibility", "visible");
    } else line.setAttribute("visibility", "hidden");
  }
  function cancelTerminal() { clearTimeout(terminalTimer); terminalTimer = null; }
  function finishMotion() { cancelTerminal(); generation++; animations.forEach(animation => animation.cancel()); animations = []; }
  function cancelPointer() {
    if (!gesture) return;
    const previous = gesture; gesture = null; previous.point.classList.remove("gm-pressed");
    try { if (previous.point.hasPointerCapture?.(previous.id)) previous.point.releasePointerCapture(previous.id); } catch {}
  }
  function showOverlay(kind) {
    cancelTerminal(); cancelPointer();
    if (!overlayKind) returnFocus = document.activeElement;
    overlayKind = kind;
    const messages = {
      confirm: ["↻", "开始新对局？", "当前棋局会被清空。\n黑方先行，双方重新开始。", "开始新对局", "继续当前局"],
      help: ["● ○", "和身边的人，下一局", "黑方先行，双方轮流在交叉点落子。\n横、竖或斜向，先连成五子及以上者获胜。\n自由规则，无禁手，双方均可连成长连。\n「悔一手」撤回最近一颗棋子。\n方向键选点，回车或空格落子，F2 新局。", "知道了", ""],
      won: [game.winner === 1 ? "●" : "○", `${playerName(game.winner)}获胜！`, `第 ${game.moves.length} 手，连成 ${game.winningLine.length} 子。\n一局好棋，再来一次？`, "新对局", "查看棋盘"],
      draw: ["● ○", "本局和棋", `双方共落下 ${game.moves.length} 手，棋盘已满。\n再来一局，继续切磋。`, "新对局", "查看棋盘"]
    };
    const [symbol, title, text, primary, secondary] = messages[kind];
    $("gm-overlay-symbol").textContent = symbol; $("gm-overlay-title").textContent = title; $("gm-overlay-text").textContent = text;
    $("gm-overlay-primary").textContent = primary; $("gm-overlay-secondary").textContent = secondary; $("gm-overlay-secondary").hidden = !secondary;
    overlay.hidden = false;
    if (active) $("gm-overlay-primary").focus({ preventScroll: true });
  }
  function hideOverlay() {
    overlayKind = null; overlay.hidden = true;
    if (active) {
      if (returnFocus && win.contains(returnFocus) && !overlay.contains(returnFocus) && !returnFocus.disabled) returnFocus.focus({ preventScroll: true });
      else focusCell(focused);
    }
    returnFocus = null;
  }
  function terminal(delay = 0) {
    cancelTerminal();
    if (game.status === "playing" || terminalDismissed || !active || document.hidden || overlayKind) return;
    if (!delay) { showOverlay(game.status); return; }
    const token = generation;
    terminalTimer = setTimeout(() => { terminalTimer = null; if (token === generation && active && !document.hidden && !overlayKind && !terminalDismissed) showOverlay(game.status); }, delay);
  }
  const playable = () => active && !win.hidden && !document.hidden && !overlayKind && game.status === "playing" && !document.querySelector("dialog[open]");
  function place(index) {
    if (!playable()) return;
    finishMotion(); focusCell(index, false);
    const result = game.place(index);
    if (!result.changed) return;
    terminalDismissed = false; save(); render();
    const stone = points.children[index].firstElementChild;
    if (stone.animate && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      const animation = stone.animate([{ transform: "scale(.7)", opacity: .3 }, { transform: "scale(1)", opacity: 1 }], { duration: 130, easing: "ease-out" }); animation.finished.catch(() => {}); animations.push(animation);
    }
    terminal(220);
  }
  function newGame() {
    cancelPointer(); pointers.clear(); finishMotion(); game.reset(); terminalDismissed = false; started = new Date().toISOString();
    hideOverlay(); focusCell(112, false); save(); render(); if (active) focusCell(112);
  }
  function requestNew() { cancelPointer(); finishMotion(); if (game.moves.length && game.status === "playing") showOverlay("confirm"); else newGame(); }
  function undo() {
    cancelPointer(); pointers.clear(); finishMotion();
    if (!game.undo()) { terminal(); return false; }
    terminalDismissed = false; hideOverlay(); save(); render(); return true;
  }
  function exportCSV() {
    const quote = value => `"${String(value).replaceAll('"', '""')}"`;
    const rows = game.moves.map((move, number) => [started, number + 1, move.player === 1 ? "black" : "white", Math.floor(move.index / 15) + 1, move.index % 15 + 1]);
    const csv = "\uFEFF" + [["date", "move", "player", "row", "column"], ...rows].map(row => row.map(quote).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" })), link = document.createElement("a");
    link.href = url; link.download = `五子棋棋谱-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const actions = { new: requestNew, undo, help: () => showOverlay("help"), export: exportCSV };
  win.querySelectorAll("[data-gm-action]").forEach(button => button.addEventListener("click", () => actions[button.dataset.gmAction]()));
  $("gm-overlay-primary").addEventListener("click", () => { if (overlayKind === "help") { hideOverlay(); terminal(); } else newGame(); });
  $("gm-overlay-secondary").addEventListener("click", () => {
    if (overlayKind === "confirm") { hideOverlay(); terminal(); }
    else { terminalDismissed = true; hideOverlay(); save(); }
  });
  board.addEventListener("pointerdown", event => {
    if (!playable() || event.button > 0 || event.isPrimary === false || pointers.size > 1) { cancelPointer(); return; }
    const point = pointAt(event.target); if (!point) return;
    cancelPointer(); gesture = { id: event.pointerId, point, index: Number(point.dataset.index), x: event.clientX, y: event.clientY, travel: 0, canceled: false };
    if (point.dataset.player === "0") point.classList.add("gm-pressed");
    try { point.setPointerCapture(event.pointerId); } catch {}
  });
  function updatePointer(event) {
    if (!gesture || gesture.id !== event.pointerId) return;
    gesture.travel += Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y); gesture.x = event.clientX; gesture.y = event.clientY;
    if (gesture.travel >= 8) { gesture.canceled = true; gesture.point.classList.remove("gm-pressed"); }
  }
  board.addEventListener("pointermove", updatePointer);
  board.addEventListener("pointerup", event => {
    if (!gesture || gesture.id !== event.pointerId) return;
    updatePointer(event);
    const previous = gesture, hit = pointAt(document.elementFromPoint(event.clientX, event.clientY));
    const commit = !previous.canceled && hit === previous.point;
    cancelPointer(); if (commit) place(previous.index);
  });
  board.addEventListener("lostpointercapture", event => { if (gesture?.id === event.pointerId) cancelPointer(); });
  board.addEventListener("contextmenu", event => event.preventDefault());
  board.addEventListener("click", event => {
    if (event.detail !== 0 || event.button > 0 || event.sourceCapabilities?.firesTouchEvents || event.pointerType && event.pointerType !== "mouse") return;
    const point = pointAt(event.target); if (point) { cancelPointer(); place(Number(point.dataset.index)); }
  });
  document.addEventListener("pointerdown", event => {
    if (event.pointerType !== "mouse") pointers.add(event.pointerId);
    if (pointers.size > 1 || gesture && gesture.id !== event.pointerId) cancelPointer();
  }, true);
  document.addEventListener("pointerup", event => pointers.delete(event.pointerId), true);
  document.addEventListener("pointercancel", event => { pointers.delete(event.pointerId); if (gesture?.id === event.pointerId) cancelPointer(); }, true);
  document.addEventListener("keydown", event => {
    if (!active || win.hidden || event.ctrlKey || event.altKey || event.metaKey || event.target.closest?.("input,select,textarea,[contenteditable='true']") || document.querySelector("dialog[open]")) return;
    if (overlayKind) { if (event.key === "Escape" && ["help", "confirm"].includes(overlayKind)) { event.preventDefault(); hideOverlay(); terminal(); } return; }
    const row = Math.floor(focused / 15), col = focused % 15;
    const next = { ArrowLeft: row * 15 + Math.max(0, col - 1), ArrowRight: row * 15 + Math.min(14, col + 1), ArrowUp: Math.max(0, row - 1) * 15 + col, ArrowDown: Math.min(14, row + 1) * 15 + col }[event.key];
    if (next !== undefined) { event.preventDefault(); focusCell(next); }
    else if ((event.key === "Enter" || event.key === " ") && board.contains(event.target)) { event.preventDefault(); cancelPointer(); place(focused); }
    else if (event.key === "F2") { event.preventDefault(); requestNew(); }
    else if (event.key === "F1") { event.preventDefault(); showOverlay("help"); }
  });
  const maximize = () => {
    cancelPointer(); pointers.clear(); finishMotion(); win.classList.toggle("maximized");
    const title = win.classList.contains("maximized") ? "还原五子棋窗口" : "最大化五子棋"; $("gm-maximize").title = title; $("gm-maximize").setAttribute("aria-label", title); terminal();
  };
  $("gm-maximize").addEventListener("click", maximize);
  $("gm-titlebar").addEventListener("dblclick", event => { if (!event.target.closest("button")) maximize(); });
  document.addEventListener("desktop:gamechange", event => {
    cancelPointer(); pointers.clear(); finishMotion(); active = event.detail?.game === "gomoku";
    if (active) { if (overlayKind) $("gm-overlay-primary").focus({ preventScroll: true }); else terminal(); }
  });
  window.addEventListener("blur", () => { cancelPointer(); pointers.clear(); finishMotion(); });
  window.addEventListener("focus", () => terminal());
  window.addEventListener("resize", () => { cancelPointer(); pointers.clear(); finishMotion(); terminal(); });
  document.addEventListener("visibilitychange", () => { cancelPointer(); pointers.clear(); finishMotion(); if (!document.hidden) terminal(); });
  window.GomokuUI = { newGame: requestNew, undo, exportCSV, snapshot: () => game.snapshot(), open: () => document.dispatchEvent(new CustomEvent("desktop:open", { detail: { game: "gomoku" } })) };
  save(); render();
})();
