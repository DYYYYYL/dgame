/* Dependency-free 2048 model. Each move examines a fixed 4 × 4 board. */
(function (global) {
  "use strict";

  const SIZE = 4, MAX_TILE = 2 ** 30;
  const directions = new Set(["left", "right", "up", "down"]);
  const copy = state => ({
    board: state.board.slice(), score: state.score, moves: state.moves,
    won: state.won, keepPlaying: state.keepPlaying, over: state.over
  });

  class Game2048 {
    constructor({ random = Math.random, state } = {}) {
      if (typeof random !== "function") throw new TypeError("random must be a function.");
      this.random = random;
      this._previous = null;
      const restored = Game2048._readState(state);
      if (restored) {
        Object.assign(this, restored);
        try { this._previous = Game2048._readState(state.undo); } catch { /* Ignore an invalid undo record. */ }
      } else this.restart();
    }

    get canUndo() { return this._previous !== null; }

    restart() {
      this.board = Array(SIZE * SIZE).fill(0);
      this.score = 0;
      this.moves = 0;
      this.won = false;
      this.keepPlaying = false;
      this.over = false;
      this._previous = null;
      this._spawn();
      this._spawn();
      return this;
    }

    move(direction) {
      if (!directions.has(direction)) throw new RangeError("Unknown 2048 direction.");
      const result = { changed: false, scoreDelta: 0, movements: [], merged: [], spawned: null, wonNow: false, over: this.over };
      if (this.over || this.won && !this.keepPlaying) return result;
      const before = copy(this), next = Array(SIZE * SIZE).fill(0);
      for (let line = 0; line < SIZE; line++) {
        const indices = Array.from({ length: SIZE }, (_, position) => {
          if (direction === "left") return line * SIZE + position;
          if (direction === "right") return line * SIZE + SIZE - 1 - position;
          if (direction === "up") return position * SIZE + line;
          return (SIZE - 1 - position) * SIZE + line;
        });
        const tiles = indices.filter(index => before.board[index]).map(index => ({ index, value: before.board[index] }));
        let target = 0;
        for (let cursor = 0; cursor < tiles.length; cursor++) {
          const tile = tiles[cursor], partner = tiles[cursor + 1];
          const merged = !!partner && tile.value === partner.value;
          const to = indices[target++];
          next[to] = tile.value * (merged ? 2 : 1);
          result.movements.push({ from: tile.index, to, value: tile.value, merged });
          if (merged) {
            result.movements.push({ from: partner.index, to, value: partner.value, merged: true });
            result.merged.push(to);
            result.scoreDelta += next[to];
            cursor++;
          }
        }
      }
      if (next.every((value, index) => value === before.board[index])) {
        result.movements = [];
        this.over = !Game2048._hasMoves(this.board);
        result.over = this.over;
        return result;
      }
      this._previous = before;
      this.board = next;
      this.score += result.scoreDelta;
      this.moves++;
      result.changed = true;
      result.wonNow = !this.won && this.board.some(value => value >= 2048);
      this.won ||= result.wonNow;
      result.spawned = this._spawn();
      this.over = !Game2048._hasMoves(this.board);
      result.over = this.over;
      return result;
    }

    continueGame() {
      if (!this.won || this.over || this.keepPlaying) return false;
      this.keepPlaying = true;
      return true;
    }

    undo() {
      if (!this._previous) return false;
      Object.assign(this, copy(this._previous));
      this._previous = null;
      return true;
    }

    snapshot() {
      return { ...copy(this), undo: this._previous ? copy(this._previous) : null };
    }

    _sample() {
      const value = Number(this.random());
      return Number.isFinite(value) ? Math.max(0, Math.min(1 - Number.EPSILON, value)) : 0;
    }

    _spawn() {
      const empty = [];
      this.board.forEach((value, index) => { if (value === 0) empty.push(index); });
      if (!empty.length) return null;
      const index = empty[Math.floor(this._sample() * empty.length)], value = this._sample() < 0.9 ? 2 : 4;
      this.board[index] = value;
      return { index, value };
    }

    static _hasMoves(board) {
      if (!board.some(Boolean)) return false;
      for (let index = 0; index < board.length; index++) {
        if (!board[index] || index % SIZE < SIZE - 1 && board[index] === board[index + 1] ||
            index < SIZE * (SIZE - 1) && board[index] === board[index + SIZE]) return true;
      }
      return false;
    }

    static _readState(state) {
      try {
        if (!state || typeof state !== "object" || !Array.isArray(state.board) || state.board.length !== SIZE * SIZE ||
            !Number.isSafeInteger(state.score) || state.score < 0 || !Number.isSafeInteger(state.moves) || state.moves < 0) return null;
        for (const value of state.board) {
          if (!Number.isSafeInteger(value) || value < 0 || value > MAX_TILE || value !== 0 && !Number.isInteger(Math.log2(value))) return null;
        }
        for (const key of ["won", "keepPlaying", "over"]) if (key in state && typeof state[key] !== "boolean") return null;
        const board = state.board.slice(), won = board.some(value => value >= 2048);
        return { board, score: state.score, moves: state.moves, won,
          keepPlaying: won && state.keepPlaying === true, over: !Game2048._hasMoves(board) };
      } catch { return null; }
    }
  }

  global.Game2048 = Game2048;
  if (typeof module !== "undefined" && module.exports) module.exports = { Game2048 };
})(typeof globalThis !== "undefined" ? globalThis : window);
