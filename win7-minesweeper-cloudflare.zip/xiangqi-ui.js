/* 中国象棋：本地进度 → 合法行棋模型 → 稳定棋盘视图 → CSV 棋谱。 */
(() => {
  "use strict";
  const $ = id => document.getElementById(id), win = $("xiangqi-window");
  if (!win || typeof Xiangqi !== "function") return;
  const KEY = "win7-xiangqi-v1", board = $("xq-board"), points = $("xq-points"), overlay = $("xq-overlay");
  const read = () => { try { const value = JSON.parse(localStorage.getItem(KEY)); return value && typeof value === "object" ? value : {}; } catch { return {}; } };
  const saved = read();
  let game;
  try { game = new Xiangqi({ state: saved.state }); } catch { game = new Xiangqi(); }
  let active = false, selected = null, legal = new Set(), focused = 85, gesture = null, overlayKind = null, returnFocus = null;
  let pendingActor = null, animations = [], generation = 0, terminalTimer = null, storageOK = true, notice = "";
  let terminalDismissed = game.status !== "playing" && saved.terminalDismissed === true;
  let started = Number.isFinite(Date.parse(saved.started)) ? saved.started : new Date().toISOString();
  const pointers = new Set(), sideName = side => side === "r" ? "红方" : "黑方", other = side => side === "r" ? "b" : "r";
  const names = { rK: "帅", bK: "将", rA: "仕", bA: "士", rB: "相", bB: "象", rN: "马", bN: "马", rR: "车", bR: "车", rC: "炮", bC: "炮", rP: "兵", bP: "卒" };
  const horizontal = Array.from({ length: 10 }, (_, row) => `M50 ${row * 100 + 50}H850`);
  const vertical = Array.from({ length: 9 }, (_, col) => col === 0 || col === 8 ? `M${col * 100 + 50} 50V950` : `M${col * 100 + 50} 50V450 M${col * 100 + 50} 550V950`);
  $("xq-grid-lines").setAttribute("d", [...horizontal, ...vertical, "M350 50L550 250 M550 50L350 250 M350 750L550 950 M550 750L350 950"].join(" "));
  points.innerHTML = Array.from({ length: 90 }, (_, index) => `<button type="button" class="xq-cell" role="gridcell" data-index="${index}" data-piece="" data-side="" data-legal="false" aria-rowindex="${Math.floor(index / 9) + 1}" aria-colindex="${index % 9 + 1}" tabindex="${index === focused ? 0 : -1}"><span class="xq-piece" aria-hidden="true"></span></button>`).join("");
  const pointAt = target => { const cell = target?.closest?.(".xq-cell"); return cell && points.contains(cell) ? cell : null; };
  function focusCell(index, move = true) {
    if (points.children[focused]) points.children[focused].tabIndex = -1;
    focused = index; points.children[index].tabIndex = 0;
    if (move && active && !win.hidden) points.children[index].focus({ preventScroll: true });
  }
  points.addEventListener("focusin", event => { const cell = pointAt(event.target); if (cell) focusCell(Number(cell.dataset.index), false); });
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify({ state: game.snapshot(), started, terminalDismissed })); storageOK = true; }
    catch { storageOK = false; }
  }
  function render() {
    const last = game.moves.at(-1);
    game.board.forEach((piece, index) => {
      const cell = points.children[index], chosen = selected === index, isLegal = legal.has(index);
      cell.dataset.piece = piece || ""; cell.dataset.side = piece ? piece[0] : ""; cell.dataset.legal = isLegal;
      cell.classList.toggle("xq-selected", chosen); cell.classList.toggle("xq-legal", isLegal);
      cell.classList.toggle("xq-last-from", last?.from === index); cell.classList.toggle("xq-last-to", last?.to === index);
      cell.firstElementChild.textContent = names[piece] || "";
      cell.setAttribute("aria-label", `第 ${Math.floor(index / 9) + 1} 行，第 ${index % 9 + 1} 列，${piece ? `${sideName(piece[0])}${names[piece]}` : "空位"}${chosen ? "，已选择" : ""}${isLegal ? "，合法落点" : ""}`);
      cell.setAttribute("aria-selected", String(chosen));
      cell.setAttribute("aria-disabled", String(game.status !== "playing"));
    });
    board.dataset.status = game.status; board.dataset.turn = game.currentPlayer; board.dataset.moves = game.moves.length;
    board.dataset.winner = game.winner || ""; board.dataset.check = !!game.inCheck; board.dataset.selected = selected === null ? "" : selected;
    $("xq-moves").textContent = game.moves.length; $("xq-undo").disabled = !game.canUndo;
    $("xq-resign").disabled = $("xq-draw").disabled = game.status !== "playing";
    const current = game.status === "won" ? game.winner : game.currentPlayer;
    $("xq-turn-piece").dataset.side = current; $("xq-turn-piece").textContent = current === "r" ? "帅" : "将";
    $("xq-turn-text").textContent = game.status === "won" ? `${sideName(game.winner)}获胜` : game.status === "draw" ? "本局和棋" : `轮到${sideName(game.currentPlayer)}行棋`;
    $("xq-check").hidden = game.status !== "playing" || !game.inCheck;
    $("xq-status").textContent = !storageOK ? "本地存储不可用，本局仍可正常游玩" : notice || (game.status === "won" ? `${sideName(game.winner)}获胜，可查看棋盘或悔一手。` : game.status === "draw" ? "双方议和，本局握手言和。" : game.inCheck ? `${sideName(game.currentPlayer)}被将军，必须先应将。` : selected !== null ? `已选${sideName(game.currentPlayer)}${names[game.board[selected]]}，请选择高亮落点。` : "点击本方棋子，查看合法落点。");
  }
  function cancelTerminal() { clearTimeout(terminalTimer); terminalTimer = null; }
  function finishMotion() { cancelTerminal(); generation++; animations.forEach(animation => animation.cancel()); animations = []; }
  function cancelPointer() {
    if (!gesture) return;
    const previous = gesture; gesture = null; previous.cell.classList.remove("xq-pressed");
    try { if (previous.cell.hasPointerCapture?.(previous.id)) previous.cell.releasePointerCapture(previous.id); } catch {}
  }
  function hideOverlay() {
    overlayKind = null; overlay.hidden = true;
    if (active) {
      if (returnFocus && win.contains(returnFocus) && !overlay.contains(returnFocus) && !returnFocus.disabled) returnFocus.focus({ preventScroll: true });
      else focusCell(focused);
    }
    returnFocus = null;
  }
  function showOverlay(kind) {
    cancelTerminal(); cancelPointer();
    if (!overlayKind) returnFocus = document.activeElement;
    overlayKind = kind;
    const why = { resigned: "对方确认认输，本局结束。", checkmate: "对方被将死，无法应将。", stalemate: "对方无合法着法，困毙判负。", captured: "对方将帅已被擒获。", "king-captured": "对方将帅已被擒获。" }[game.reason] || "本局对弈结束。";
    const messages = {
      confirm: ["新", "开始新对局？", "当前棋局会被清空。\n红方先行，双方重新开始。", "开始新对局", "继续当前局"],
      resign: ["让", `${sideName(pendingActor)}确认认输？`, `请${sideName(pendingActor)}确认自己的选择。\n确认后，${sideName(other(pendingActor))}将获胜。`, `${sideName(pendingActor)}确认认输`, "继续对局"],
      agreement: ["和", `请${sideName(other(pendingActor))}确认议和`, `${sideName(pendingActor)}提出和棋。\n请${sideName(other(pendingActor))}确认是否同意。\n只有双方同意，才会结束本局。`, `${sideName(other(pendingActor))}同意和棋`, "继续对局"],
      help: ["棋", "中国象棋 · 同屏对弈", "车走直线；马走日，不能蹩马腿；炮隔一子吃子。\n兵、卒过河后可横走，不能后退。\n将、帅在九宫走一格；士、仕斜走一格不出九宫。\n象、相走田，不能塞象眼，也不能越河。\n被将军必须应将，将帅不得照面。\n将死、困毙均判负。红方先行，双方轮流。\n长将、循环等赛事裁决由双方协商，可使用议和。\n方向键选点，回车或空格选择、落子，F2 新局。", "知道了", ""],
      won: [game.winner === "r" ? "帅" : "将", `${sideName(game.winner)}获胜！`, `${why}\n本局共行 ${game.moves.length} 手，再来切磋一局？`, "新对局", "查看棋盘"],
      draw: ["和", "双方握手言和", `双方同意和棋，本局结束。\n共行 ${game.moves.length} 手，再来一局？`, "新对局", "查看棋盘"]
    };
    const [symbol, title, text, primary, secondary] = messages[kind];
    $("xq-overlay-symbol").textContent = symbol; $("xq-overlay-title").textContent = title; $("xq-overlay-text").textContent = text;
    $("xq-overlay-primary").textContent = primary; $("xq-overlay-secondary").textContent = secondary; $("xq-overlay-secondary").hidden = !secondary;
    overlay.hidden = false; if (active) $("xq-overlay-primary").focus({ preventScroll: true });
  }
  function terminal(delay = 0) {
    cancelTerminal();
    if (game.status === "playing" || terminalDismissed || !active || document.hidden || overlayKind) return;
    if (!delay) { showOverlay(game.status); return; }
    const token = generation;
    terminalTimer = setTimeout(() => { terminalTimer = null; if (token === generation && active && !document.hidden && !overlayKind && !terminalDismissed) showOverlay(game.status); }, delay);
  }
  const playable = () => active && !win.hidden && !document.hidden && !overlayKind && game.status === "playing" && !document.querySelector("dialog[open]");
  function clearSelection() { selected = null; legal = new Set(); notice = ""; }
  function activate(index) {
    if (!playable()) return;
    finishMotion(); focusCell(index, false); notice = "";
    const piece = game.board[index];
    if (piece && piece[0] === game.currentPlayer) {
      if (selected === index) clearSelection();
      else { selected = index; legal = new Set(game.legalMoves(index)); if (!legal.size) notice = "该棋子目前没有合法着法，请选择其他棋子。"; }
      render(); return;
    }
    if (selected === null || !legal.has(index)) { notice = selected === null ? "请先选择本方棋子。" : "此处不可落子，请选择高亮落点。"; render(); return; }
    const from = selected, result = game.move(from, index);
    if (!result.changed) { clearSelection(); render(); return; }
    clearSelection(); terminalDismissed = false; save(); render();
    const element = points.children[index].firstElementChild;
    if (element.animate && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      const dx = (from % 9 - index % 9) * points.clientWidth / 9, dy = (Math.floor(from / 9) - Math.floor(index / 9)) * points.clientHeight / 10;
      const animation = element.animate([{ transform: `translate(${dx}px,${dy}px)` }, { transform: "translate(0,0)" }], { duration: 130, easing: "cubic-bezier(.2,.7,.25,1)" }); animation.finished.catch(() => {}); animations.push(animation);
    }
    terminal(220);
  }
  function newGame() {
    cancelPointer(); pointers.clear(); finishMotion(); game.reset(); clearSelection(); terminalDismissed = false; started = new Date().toISOString();
    hideOverlay(); focusCell(85, false); save(); render(); if (active) focusCell(85);
  }
  function requestNew() { cancelPointer(); finishMotion(); if (game.moves.length && game.status === "playing") showOverlay("confirm"); else newGame(); }
  function undo() {
    cancelPointer(); pointers.clear(); finishMotion(); clearSelection();
    if (!game.undo()) { render(); terminal(); return false; }
    terminalDismissed = false; hideOverlay(); save(); render(); return true;
  }
  function requestResult(kind) {
    if (game.status !== "playing") return;
    cancelPointer(); finishMotion(); pendingActor = game.currentPlayer; showOverlay(kind);
  }
  function exportCSV() {
    const quote = value => `"${String(value ?? "").replaceAll('"', '""')}"`;
    const rows = game.moves.map((move, index) => [started, index + 1, sideName(move.player || move.piece[0]), names[move.piece], Math.floor(move.from / 9) + 1, move.from % 9 + 1, Math.floor(move.to / 9) + 1, move.to % 9 + 1, names[move.captured] || "", game.status, game.winner ? sideName(game.winner) : "", game.reason]);
    if (!rows.length) rows.push([started, "", "", "", "", "", "", "", "", game.status, game.winner ? sideName(game.winner) : "", game.reason]);
    const csv = "\uFEFF" + [["date", "move", "player", "piece", "fromRow", "fromColumn", "toRow", "toColumn", "captured", "status", "winner", "reason"], ...rows].map(row => row.map(quote).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" })), link = document.createElement("a");
    link.href = url; link.download = `中国象棋棋谱-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const actions = { new: requestNew, undo, help: () => showOverlay("help"), export: exportCSV, resign: () => requestResult("resign"), draw: () => requestResult("agreement") };
  win.querySelectorAll("[data-xq-action]").forEach(button => button.addEventListener("click", () => actions[button.dataset.xqAction]()));
  $("xq-overlay-primary").addEventListener("click", () => {
    if (overlayKind === "help") { hideOverlay(); terminal(); }
    else if (overlayKind === "resign" || overlayKind === "agreement") {
      const changed = overlayKind === "resign" ? game.resign(pendingActor) : game.agreeDraw();
      if (changed) { clearSelection(); terminalDismissed = false; hideOverlay(); save(); render(); terminal(); }
    } else newGame();
  });
  $("xq-overlay-secondary").addEventListener("click", () => {
    if (["confirm", "resign", "agreement"].includes(overlayKind)) { hideOverlay(); terminal(); }
    else { terminalDismissed = true; hideOverlay(); save(); }
  });
  board.addEventListener("pointerdown", event => {
    if (!playable() || event.button > 0 || event.isPrimary === false || pointers.size > 1) { cancelPointer(); return; }
    const cell = pointAt(event.target); if (!cell) return;
    cancelPointer(); gesture = { id: event.pointerId, cell, index: Number(cell.dataset.index), x: event.clientX, y: event.clientY, travel: 0, canceled: false };
    cell.classList.add("xq-pressed");
    try { cell.setPointerCapture(event.pointerId); } catch {}
  });
  function updatePointer(event) {
    if (!gesture || gesture.id !== event.pointerId) return;
    gesture.travel += Math.hypot(event.clientX - gesture.x, event.clientY - gesture.y); gesture.x = event.clientX; gesture.y = event.clientY;
    if (gesture.travel >= 8) { gesture.canceled = true; gesture.cell.classList.remove("xq-pressed"); }
  }
  board.addEventListener("pointermove", updatePointer);
  board.addEventListener("pointerup", event => {
    if (!gesture || gesture.id !== event.pointerId) return;
    updatePointer(event);
    const previous = gesture, hit = pointAt(document.elementFromPoint(event.clientX, event.clientY)), commit = !previous.canceled && hit === previous.cell;
    cancelPointer(); if (commit) activate(previous.index);
  });
  board.addEventListener("lostpointercapture", event => { if (gesture?.id === event.pointerId) cancelPointer(); });
  board.addEventListener("contextmenu", event => event.preventDefault());
  board.addEventListener("click", event => {
    if (event.detail !== 0 || event.button > 0 || event.sourceCapabilities?.firesTouchEvents || event.pointerType && event.pointerType !== "mouse") return;
    const cell = pointAt(event.target); if (cell) { cancelPointer(); activate(Number(cell.dataset.index)); }
  });
  document.addEventListener("pointerdown", event => {
    if (event.pointerType !== "mouse") pointers.add(event.pointerId);
    if (pointers.size > 1 || gesture && gesture.id !== event.pointerId) cancelPointer();
  }, true);
  document.addEventListener("pointerup", event => pointers.delete(event.pointerId), true);
  document.addEventListener("pointercancel", event => { pointers.delete(event.pointerId); if (gesture?.id === event.pointerId) cancelPointer(); }, true);
  document.addEventListener("keydown", event => {
    if (!active || win.hidden || event.ctrlKey || event.altKey || event.metaKey || event.target.closest?.("input,select,textarea,[contenteditable='true']") || document.querySelector("dialog[open]")) return;
    if (overlayKind) { if (event.key === "Escape" && ["help", "confirm", "resign", "agreement"].includes(overlayKind)) { event.preventDefault(); hideOverlay(); terminal(); } return; }
    const row = Math.floor(focused / 9), col = focused % 9;
    const next = { ArrowLeft: row * 9 + Math.max(0, col - 1), ArrowRight: row * 9 + Math.min(8, col + 1), ArrowUp: Math.max(0, row - 1) * 9 + col, ArrowDown: Math.min(9, row + 1) * 9 + col }[event.key];
    if (next !== undefined) { event.preventDefault(); cancelPointer(); focusCell(next); }
    else if ((event.key === "Enter" || event.key === " ") && board.contains(event.target)) { event.preventDefault(); cancelPointer(); const cell = pointAt(event.target); activate(cell ? Number(cell.dataset.index) : focused); }
    else if (event.key === "Escape" && selected !== null) { event.preventDefault(); cancelPointer(); clearSelection(); render(); }
    else if (event.key === "F2") { event.preventDefault(); requestNew(); }
    else if (event.key === "F1") { event.preventDefault(); showOverlay("help"); }
  });
  const maximize = () => {
    cancelPointer(); pointers.clear(); finishMotion(); win.classList.toggle("maximized");
    const title = win.classList.contains("maximized") ? "还原中国象棋窗口" : "最大化中国象棋"; $("xq-maximize").title = title; $("xq-maximize").setAttribute("aria-label", title); terminal();
  };
  $("xq-maximize").addEventListener("click", maximize);
  $("xq-titlebar").addEventListener("dblclick", event => { if (!event.target.closest("button")) maximize(); });
  document.addEventListener("desktop:gamechange", event => {
    cancelPointer(); pointers.clear(); finishMotion(); active = event.detail?.game === "xiangqi";
    if (active) { if (overlayKind) $("xq-overlay-primary").focus({ preventScroll: true }); else terminal(); }
  });
  window.addEventListener("blur", () => { cancelPointer(); pointers.clear(); finishMotion(); });
  window.addEventListener("focus", () => terminal());
  window.addEventListener("resize", () => { cancelPointer(); pointers.clear(); finishMotion(); terminal(); });
  document.addEventListener("visibilitychange", () => { cancelPointer(); pointers.clear(); finishMotion(); if (!document.hidden) terminal(); });
  window.XiangqiUI = { newGame: requestNew, undo, exportCSV, snapshot: () => game.snapshot(), open: () => document.dispatchEvent(new CustomEvent("desktop:open", { detail: { game: "xiangqi" } })) };
  save(); render();
})();
